## 0.40 - Formularios públicos
- Gestión de tablas candidatas desde Opciones.
- Selección explícita de campos visibles y obligatorios.
- URL aleatoria revocable por formulario, activación y desactivación.
- Endpoint público de inserción, sin lectura de datos.
- Protección CSRF, honeypot, validación y limitación básica por sesión.

## 0.39 - Editor de estructura en Opciones
- Pestañas Aplicaciones y Estructura de datos.
- Gestión de tablas, campos y relaciones con previsualización y migración.
- Protección de tablas internas.
- Conservado el diseñador de Modelo de datos.
- Limitaciones del conector: cambio de tipos y eliminación de FK no automatizados.

## 0.38 - Fusión interfaz de configuración y JocarsaBBDD
- Recuperada pantalla de configuración de la versión 036.
- Conservada API JocarsaBBDD de la versión 037.
- Excluidas tablas internas __crimson_ de asignación a módulos.
- Error de carga visible en la pantalla.

## 0.34 - Migración a JocarsaBBDD
- Eliminada la dependencia activa de SQLite/PDO SQLite.
- Nueva capa `nucleo/JocarsaDB.php`.
- Persistencia en la base `crimson` de JocarsaBBDD.
- `Identificador` se adapta al `id` interno del motor.
- El campo lógico `activo` se adapta a `__crimson_activo` para no colisionar con el borrado lógico interno.
- API, login, usuarios, permisos, módulos, CRUD, API E/S, instalador y diseñador migrados al conector PHP nativo.
- Migraciones protegidas mediante transacciones JocarsaBBDD.

## 0.21 - corrección [object Object]
- Navegación de módulos compatible con objetos `{modulo,nombre}` y cadenas.
- Cache-busting explícito en componentes e incluir.js para impedir que el navegador reutilice componentes antiguos.
- El clic de módulo sólo carga su `modulo.json`; no ejecuta CRUD hasta seleccionar una tabla.

## 020.1 - Navegación por módulos corregida
- La API `modulos` lee cada `modulo.json`.
- La API `menu` devuelve únicamente las tablas declaradas en el módulo seleccionado.
- Seleccionar un módulo ya no ejecuta CRUD contra el nombre del módulo.
- Se evita caché de componentes/API para que los cambios se reflejen inmediatamente.
- Se limpia `tablaActual` al cambiar de módulo.

## [0.6] — 2026-09-17

### Identidad visual y cabecera

* Cambiado el color corporativo principal de `mediumseagreen` a `crimson`.
* El color continúa centralizado mediante la variable CSS `--color-principal`.
* Establecida `Ubuntu` como fuente primaria de la interfaz, con `sans-serif` como alternativa.
* Recuperada la identidad corporativa permanente `jocarsa | crimson` en la zona izquierda de la cabecera.
* La zona central de la cabecera muestra la tabla activa, la operación actual y las acciones disponibles.
* La zona derecha mantiene la identidad y opciones del usuario.
* Reducida la altura de la cabecera para conseguir una interfaz más compacta.
* Normalizados los espaciados mediante las variables CSS `--padding` y `--gap`.
* Unificados los paddings de cabecera, navegación, contenido, tablas, formularios y pie de página.

### Formularios

* Añadida separación vertical entre grupos de campos mediante `--gap:10px`.
* La primera columna de los formularios se ajusta automáticamente al texto de campo más ancho.
* La segunda columna utiliza el espacio restante disponible.
* Los campos relacionados mediante clave foránea utilizan ahora `input` con `datalist` en lugar de `select`.
* El usuario puede escribir o seleccionar el valor descriptivo de un registro relacionado.
* Al guardar, el componente CRUD resuelve el valor mostrado y almacena el `Identificador` correspondiente.
* Al actualizar, las claves foráneas almacenadas se muestran nuevamente mediante su representación descriptiva.

### Detección automática de instalación

* Añadido el endpoint `api.php?bloque=estado`.
* El endpoint puede comprobar la existencia de `data/crimson.sqlite` sin necesitar abrir previamente la base de datos.
* Al cargar `index.html`, Crimson consulta automáticamente el estado de instalación.
* Si la base de datos existe, se carga normalmente la aplicación.
* Si la base de datos no existe, el usuario es redirigido automáticamente a `instalacion/instalar.php`.
* La carga de los componentes de la aplicación solamente comienza cuando se ha confirmado que Crimson está instalado.

### Instalador

* El instalador carga automáticamente el contenido de `modelodedatos.md`.
* El modelo de datos se presenta dentro de un `<textarea>` editable antes de realizar la instalación.
* El usuario puede modificar directamente el modelo antes de crear la base de datos.
* Al confirmar la instalación, el contenido del editor se guarda nuevamente en `modelodedatos.md`.
* La base de datos SQLite se genera utilizando el modelo guardado.
* Adaptada la interfaz del instalador a la identidad visual `crimson`.
* Aplicada la fuente Ubuntu y el mismo sistema básico de espaciado utilizado por la aplicación.
* El instalador detecta una instalación existente y evita sobrescribirla.
* Corregida la limpieza en caso de error para impedir que una ejecución del instalador pueda eliminar accidentalmente una base de datos preexistente.

### Flujo de arranque

El arranque de Crimson queda ahora automatizado:

`index.html → api.php?bloque=estado`

Si existe la base de datos:

`estado instalado → incluir.js → componentes → Crimson ERP`

Si no existe:

`estado no instalado → instalar.php → modelodedatos.md → crimson.sqlite → Crimson ERP`

---

# Changelog — Crimson ERP

Registro de cambios y evolución del proyecto **Crimson ERP**.

El proyecto se encuentra actualmente en una fase inicial de desarrollo y construcción de su arquitectura base.

---

## [0.4] — 2026-09-17

### API conectada a SQLite

* Sustituido el menú estático de la API por una consulta real a SQLite.
* El endpoint `menu` obtiene automáticamente las tablas existentes en `data/crimson.sqlite`.
* La consulta excluye las tablas internas de SQLite.
* Las nuevas tablas incorporadas mediante el modelo de datos aparecen automáticamente en el menú sin necesidad de modificar el código PHP o JavaScript.

### Endpoint de tablas

* Actualizado el endpoint `tabla` para trabajar con cualquier tabla de la base de datos.
* Nueva llamada:

  `api/api.php?bloque=tabla&tabla=Clientes`

* El endpoint devuelve:
  * nombre de la tabla;
  * estructura real de columnas;
  * contenido completo de la tabla.
* La estructura se obtiene mediante `PRAGMA table_info`.
* Los registros se obtienen mediante `SELECT *`.
* Eliminados los datos estáticos de productos del endpoint `tabla`.
* Validación previa de que la tabla solicitada existe.
* Se impide consultar mediante el endpoint una tabla SQLite interna.
* Mantenimiento de respuestas JSON con soporte Unicode.
* Captura de excepciones y mensajes de depuración.

### Menú dinámico

* Actualizado `nucleo/componentes/menu.html`.
* El menú continúa obteniendo automáticamente las tablas desde el endpoint `menu`.
* Cada elemento del menú incorpora ahora una acción de carga.
* Al pulsar una tabla se realiza una petición `fetch()` al endpoint `tabla`.
* El nombre de la tabla se envía mediante `encodeURIComponent()`.
* Se evita la navegación normal del enlace mediante `preventDefault()`.

### Visualización dinámica de tablas

* El área principal se actualiza al seleccionar una tabla del menú.
* Se muestra el nombre de la tabla seleccionada.
* Las cabeceras se construyen a partir de la estructura real devuelta por SQLite.
* Ya no se deducen las columnas a partir del primer registro.
* Las tablas sin registros pueden mostrar correctamente sus cabeceras.
* Las filas se construyen dinámicamente utilizando el orden definido por la estructura SQLite.
* Los valores `NULL` se representan como celdas vacías.
* El mismo código permite visualizar `Clientes`, `Productos`, `Pedidos` y cualquier tabla futura.

### Evolución de la arquitectura

El flujo de datos pasa a ser completamente dinámico:

`modelodedatos.md → SQLite → api.php → menu.html → interfaz`

Esto permite que una nueva tabla añadida al modelo, instalada o migrada a SQLite, pueda aparecer en el menú y visualizarse desde la interfaz sin crear código específico para esa entidad.

---

## [0.3] — 2026-09-17

### Persistencia SQLite

* Incorporado sistema de persistencia basado en SQLite.
* La base de datos se almacena en `data/crimson.sqlite`.
* La estructura de la base de datos se define declarativamente mediante `instalacion/modelodedatos.md`.
* Separación entre definición del modelo, instalación inicial y migraciones posteriores.

### Modelo de datos

* Creado `instalacion/modelodedatos.md` como fuente de verdad del esquema.
* Las tablas se definen mediante una línea con el nombre de la entidad.
* Los campos se definen mediante líneas iniciadas por `-`.
* Los campos sin tipo explícito utilizan `TEXT`.
* Se permite indicar tipos SQLite mediante la sintaxis `campo:TIPO`.
* Tipos admitidos:
  * `TEXT`
  * `INTEGER`
  * `REAL`
  * `BLOB`
  * `NUMERIC`
* Validación de tablas duplicadas.
* Validación de campos duplicados.
* Validación de tipos no permitidos.
* Validación de referencias a tablas inexistentes.

### Identificadores automáticos

* Todas las tablas reciben automáticamente un primer campo llamado `Identificador`.
* `Identificador` se crea como `INTEGER PRIMARY KEY AUTOINCREMENT`.
* El campo no debe declararse manualmente en `modelodedatos.md`.
* El instalador detecta y rechaza una declaración manual de `Identificador`.

### Relaciones entre tablas

* Incorporada declaración de claves foráneas directamente desde el modelo.
* Nueva sintaxis:

  `-cliente FK Clientes`

* Una FK referencia automáticamente `Identificador` de la tabla indicada.
* Los campos FK sin tipo explícito se crean como `INTEGER`.
* También se admite tipo explícito, por ejemplo:

  `-cliente:INTEGER FK Clientes`

* Activación de `PRAGMA foreign_keys = ON`.
* Validación de integridad mediante `PRAGMA foreign_key_check`.

### Modelo inicial

Definidas las entidades:

* `Clientes`
  * nombre
  * apellidos
  * fecha_nacimiento
  * dni
  * email
* `Productos`
  * nombre
  * precio
  * dimensiones
  * descripcion
* `Pedidos`
  * fecha
  * numero
  * cliente → `Clientes.Identificador`
  * producto → `Productos.Identificador`

### Instalador

* Desarrollado `instalacion/instalar.php`.
* Lectura automática de `modelodedatos.md`.
* Creación automática de la carpeta `data` cuando no existe.
* Creación de `data/crimson.sqlite`.
* Creación automática de todas las tablas definidas en el modelo.
* Creación automática de `Identificador` en cada tabla.
* Creación de relaciones FK.
* Uso de transacciones durante la instalación.
* Rollback en caso de error.
* Comprobación de la extensión PHP `pdo_sqlite`.
* El instalador no sobreescribe una base existente y deriva las actualizaciones a `migrar.php`.

### Información de instalación

* Ampliada la interfaz del instalador para informar detalladamente del resultado.
* Muestra el nombre de cada tabla creada.
* Muestra todos los campos de cada tabla.
* Muestra el tipo SQLite de cada campo.
* Identifica la clave primaria.
* Identifica las claves foráneas.
* Muestra la tabla y el campo referenciados.
* Informa de la ubicación final de la base de datos.
* Informa del número de tablas creadas.
* Presentación diferenciada de instalación correcta y errores.

### Migraciones

* Desarrollado `instalacion/migrar.php`.
* Comparación automática entre `modelodedatos.md` y el esquema SQLite existente.
* Detección de:
  * tablas nuevas;
  * tablas eliminadas;
  * campos nuevos;
  * campos eliminados;
  * cambios de tipo;
  * claves foráneas nuevas;
  * cambios en claves foráneas;
  * tablas antiguas sin el campo `Identificador`.
* Clasificación de operaciones como seguras o destructivas.
* Presentación previa de todos los cambios antes de ejecutar la migración.
* Confirmación explícita para cambios destructivos.

### Seguridad de las migraciones

* Creación automática de una copia de seguridad antes de modificar el esquema.
* Formato de copia:

  `crimson.sqlite.backup-YYYYMMDD-HHMMSS`

* Uso de transacciones durante la migración.
* Rollback ante errores.
* Las modificaciones no soportadas directamente por `ALTER TABLE` se realizan reconstruyendo la tabla.
* Durante la reconstrucción se conservan los campos compatibles.
* Se conserva `Identificador` cuando ya existe.
* Si una tabla antigua no tiene `Identificador`, SQLite genera los nuevos identificadores automáticamente.
* Los cambios de tipo utilizan conversión mediante `CAST`.
* Verificación final del esquema después de migrar.
* Comprobación final de integridad de claves foráneas.

### Estado de persistencia

* Crimson ERP dispone ahora de una primera capa de persistencia real.
* El esquema queda desacoplado del código PHP mediante un modelo de datos declarativo.
* El sistema puede instalar una base desde cero y evolucionar posteriormente su estructura mediante migraciones.

---

## [0.2] — 2026-09-17

### Añadimos changelog

* Creado `changelog.md` para registrar la evolución del proyecto.

---

## [0.1] — 2026-09-17

### Estado inicial

Primera versión funcional de **Crimson ERP**.

Esta versión establece la estructura básica sobre la que se desarrollarán los diferentes módulos y funcionalidades del ERP.

### Arquitectura

* Creada la estructura inicial del proyecto.
* Separación del sistema en:
  * `api/`
  * `modulos/`
  * `nucleo/`
* Creado el núcleo común de la aplicación.
* Separación de componentes HTML reutilizables.
* Separación de estilos CSS.
* Separación de JavaScript.
* Preparación de la carpeta `modulos/` para futuros módulos del ERP.

### Interfaz

* Creada la estructura principal de la aplicación:
  * Cabecera.
  * Menú lateral.
  * Área principal de trabajo.
  * Pie de página.
* Cabecera con:
  * Identidad corporativa de jocarsa | crimson.
  * Herramientas principales.
  * Identificación del usuario.
  * Acceso a opciones.
* Pie de página con:
  * Identidad de la aplicación.
  * Estado/información del sistema.
  * Usuario y rol.
* Altura fija para cabecera y pie de página.
* Área central adaptable automáticamente al espacio disponible.
* Menú lateral integrado con el mismo lenguaje visual de la aplicación.
* Definición de variables CSS globales para color, márgenes y dimensiones principales.
* Estilo base para tablas de datos.

### Componentes

Implementados los primeros componentes reutilizables:

* `cabecera.html`
* `menu.html`
* `clientes.html`
* `principal.html`
* `piedepagina.html`

### Carga dinámica

* Implementado sistema de inclusión dinámica mediante el atributo `data-include`.
* Creado `incluir.js` como cargador de componentes.
* Los componentes se obtienen mediante `fetch()`.
* Ejecución automática de los scripts contenidos dentro de los componentes cargados.
* Gestión básica de errores cuando un componente no puede cargarse.

### API

* Creada API inicial en `api/api.php`.
* Implementado endpoint lógico `menu`.
* Implementado endpoint lógico `tabla`.
* El menú principal puede obtener sus elementos dinámicamente desde la API.
* Implementados datos JSON iniciales para pruebas.

### Datos

* Creado conjunto inicial de productos de demostración.
* Cada producto dispone actualmente de:
  * ID.
  * Nombre.
  * Categoría.
  * Precio.
  * Stock.
* Generación dinámica de tablas HTML a partir de objetos JSON.
* Las columnas se generan automáticamente utilizando las claves de los objetos.
* Las filas se generan automáticamente a partir de los registros recibidos.

### Estado de persistencia

* Todavía no existe una base de datos persistente.
* Los datos actuales son datos estáticos de demostración proporcionados por la API.
* La persistencia definitiva queda pendiente para versiones posteriores.

### Estado de la versión

**Versión:** `0.1`

**Fase:** prototipo funcional / arquitectura inicial.

La versión 0.1 proporciona la base estructural, visual y técnica necesaria para comenzar a implementar los módulos funcionales de Crimson ERP.


## Módulos configurables por JSON
- Añadido `modulo.json` a cada módulo con la lista explícita de tablas visibles.
- Añadidos módulos CRM, catálogo, finanzas, contabilidad, proyectos, fabricación, activos, soporte, administración, maestros, documental y auditoría.
- Todas las tablas del modelo ERP quedan asignadas al menos a un módulo.

## Módulos filtrando tablas

* La primera columna representa módulos y ya no intenta abrir el nombre del módulo como si fuera una tabla.
* Al seleccionar un módulo se lee su `modulo.json` mediante `api.php?bloque=menu&modulo=...`.
* La segunda columna se vacía y se rellena exclusivamente con las tablas declaradas en `tablas` para ese módulo.
* El endpoint `modulos` devuelve ahora el identificador y el nombre visible de cada módulo.
* El endpoint `menu` valida tanto el módulo solicitado como la existencia real de las tablas declaradas en SQLite.


## 0.22 - Pulido visual
- Ajuste CSS profesional manteniendo la estructura y el espíritu Crimson.
- Navegación más compacta, estado activo más claro, tablas y formularios refinados.
- Sin cambios funcionales en PHP/JS.


## 0.23 - Modelo visual y migraciones
- schema.sql sustituye a modelodedatos.md en el instalador.
- Editor visual reducido a entidades, campos y relaciones FK.
- Vista previa SQL de migración.
- Aplicación de migraciones con backup automático y rollback por restauración.
- Historial SQL en instalacion/migraciones/.


## 0.24 - Diseñador visual como instalador
- El instalador ES el diseñador visual de entidades y relaciones FK.
- Ya no se importan datos de demostración durante la instalación.
- El diagrama genera schema.sql y crea crimson.sqlite desde cero.
- El mismo diseñador queda disponible dentro del ERP para migraciones y actualizaciones.


## 0.25 - Instalador visual corregido
- La creación de base elimina primero crimson.sqlite y sus archivos WAL/SHM.
- Evita el error `table ... already exists` al reinstalar.
- Nueva opción `Vaciar diagrama`.
- Nueva opción `Redistribuir`, que organiza entidades por niveles de dependencia FK.
- Las mismas herramientas están disponibles en el diseñador de migraciones.


## 0.26 - Configuración de módulos
- El botón Opciones abre la configuración.
- Lista las carpetas/módulos existentes.
- Permite crear y eliminar módulos.
- Permite asignar y quitar tablas SQLite a cada módulo editando su modulo.json.
- Eliminar un módulo no elimina tablas ni datos SQLite.


## 0.27 - Botón Opciones corregido
- Se ha corregido el acceso a configuracion.php desde la cabecera.
- Se fuerza navegación explícita en Opciones y Modelo de datos.
- Se actualiza la versión de todos los includes dinámicos a v=027 para evitar que el navegador reutilice cabecera.html antigua.
- Se añade no-cache al documento principal.


## 0.28 - Presets de instalación
- El instalador permite empezar desde cero.
- Permite cargar presets antes de crear SQLite.
- Incluye ERP completo actual y Empresa pequeña.
- Los presets son JSON editables y reemplazan el diagrama, que puede seguir modificándose visualmente.


## 0.29 - Usuarios, login y permisos
- El instalador solicita nombre, usuario, email y contraseña del administrador inicial.
- Se crean tablas internas __crimson_users y __crimson_permissions, fuera del modelo de negocio.
- Nueva pantalla de login y cierre de sesión.
- Solo administradores acceden a Usuarios, Modelo de datos y Opciones.
- CRUD administrativo de usuarios.
- Asignación de módulos por usuario.
- Permisos independientes por módulo: seleccionar, insertar, actualizar y eliminar.
- La API valida los permisos en servidor; no son solo controles visuales.
- Los usuarios solo ven los módulos para los que tienen al menos un permiso.


## 0.30 - Flujo instalación / login corregido
- Si no existe crimson.sqlite, login.php redirige inmediatamente al instalador.
- Una instalación solo se considera válida si existen también __crimson_users y __crimson_permissions.
- Una base antigua sin sistema de autenticación vuelve al instalador en lugar de mostrar un login imposible.
- api/auth.php informa del estado no instalado sin intentar autenticar.
- index.html mantiene el orden correcto: instalación -> autenticación -> aplicación.


## 0.31 - Interfaz, perfil, permisos y navegación del diagrama
- Logo y favicon: https://static.jocarsa.com/logos/crimson.svg
- Cabecera reorganizada con usuario y administración a la derecha.
- El nombre del usuario abre Mi perfil; cada usuario puede cambiar nombre, email y contraseña.
- Insertar pasa a ser un botón flotante + abajo a la derecha.
- Insertar, actualizar y eliminar permanecen visibles sin permiso, pero deshabilitados.
- Gestión de permisos: botones Todo y Nada independientes para cada módulo.
- Diseñador ER: rueda del ratón para zoom y botón central + arrastrar para pan.


## 0.32 - FK genéricas mediante input + datalist
- Los formularios detectan automáticamente las FK reales mediante PRAGMA foreign_key_list.
- Cada FK se presenta como input + datalist, nunca como select.
- Las opciones muestran una etiqueta humana de la tabla relacionada y conservan internamente su clave.
- La etiqueta prioriza nombre, razón social, descripción, título, código, username, email, número o referencia.
- Se añade la clave [#ID] a la etiqueta para evitar ambigüedad entre registros con el mismo nombre.
- Al actualizar un registro se transforma automáticamente el ID almacenado en su etiqueta legible.
- Al guardar se convierte de nuevo la etiqueta elegida al valor real de la FK.
- La solución es genérica y no contiene reglas específicas para empresas, usuarios ni ninguna otra tabla.


## 0.33 - Relaciones FK visibles en listados
- Las columnas FK muestran automáticamente el registro relacionado, no únicamente su ID.
- Se usa PRAGMA foreign_key_list, por lo que no hay configuración específica por tabla.
- Se reutiliza la misma etiqueta humana que en los datalist de insertar/actualizar.
- El valor real de la FK permanece intacto en SQLite.
- Al pasar el ratón por la celda se puede consultar el ID real mediante el title.
- Se usa cache durante cada petición para evitar repetir consultas para una misma relación/ID.
