(()=>{'use strict';
const KEY='ju-a11y-v7-'; const root=document.documentElement;
const read=(k,d)=>{try{return localStorage.getItem(KEY+k)??d}catch{return d}};
const save=(k,v)=>{try{localStorage.setItem(KEY+k,v)}catch{}};
const actionSelector='a,button,input:not([type=hidden]),select,textarea,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=option],[role=switch],[tabindex]:not([tabindex="-1"]),[onclick]';
const human=s=>String(s||'').replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();
function describe(el){const explicit=el.getAttribute('title')||el.getAttribute('data-help');if(explicit)return explicit;
 const aria=el.getAttribute('aria-label');const labelled=el.labels?.[0]?.textContent;const txt=human(aria||labelled||el.innerText||el.textContent||el.getAttribute('placeholder')||el.getAttribute('name')||el.getAttribute('alt')||'');
 if(el.matches('input[type=checkbox],[role=switch]'))return 'Activar o desactivar '+(txt||'esta opción')+'. Pulsa Espacio para cambiar.';
 if(el.matches('input[type=radio]'))return 'Seleccionar '+(txt||'esta opción')+'. Usa las flechas para cambiar de opción.';
 if(el.matches('input,textarea,[contenteditable=true]'))return 'Introducir '+(txt||'información')+'. Pulsa Tab para continuar.';
 if(el.matches('select'))return 'Elegir '+(txt||'una opción')+'. Usa las flechas para seleccionar.';
 if(el.matches('summary'))return 'Mostrar u ocultar '+(txt||'detalles')+'. Pulsa Intro para cambiar.';
 if(el.matches('a,[role=link]'))return 'Ir a '+(txt||el.getAttribute('href')||'este enlace')+'. Pulsa Intro para abrir.';
 if(el.matches('button,[role=button],[onclick]'))return 'Acción: '+(txt||'activar este control')+'. Pulsa Intro o Espacio.';
 return 'Interactuar con '+(txt||'este elemento')+'.';}
function decorate(scope=document){const els=[];if(scope.nodeType===1&&scope.matches?.(actionSelector))els.push(scope);scope.querySelectorAll?.(actionSelector).forEach(x=>els.push(x));for(const el of els){const original=el.getAttribute('title');if(original?.trim()){el.setAttribute('data-help',original);el.removeAttribute('title')}else if(!el.hasAttribute('data-help')){const help=describe(el);if(help)el.setAttribute('data-help',help)}}}
const DELAY=5000, FADE=260, STILL=3;
let tip, pending=null, active=null, timer=null, fadeTimer=null, anchorX=0, anchorY=0;
function cancelTimer(){clearTimeout(timer);timer=null}
function hide(){cancelTimer();pending=null;active=null;if(!tip)return;tip.classList.remove('ju-help-visible');clearTimeout(fadeTimer);fadeTimer=setTimeout(()=>{if(!tip.classList.contains('ju-help-visible'))tip.hidden=true},FADE)}
function show(el){if(!el?.isConnected||!el.getAttribute('data-help'))return;clearTimeout(fadeTimer);tip.textContent=el.getAttribute('data-help');tip.hidden=false;tip.classList.remove('ju-help-visible');const r=el.getBoundingClientRect();const w=tip.offsetWidth,h=tip.offsetHeight;tip.style.left=Math.max(8,Math.min(innerWidth-w-8,r.left))+'px';tip.style.top=(r.bottom+h+10<innerHeight?r.bottom+8:Math.max(8,r.top-h-8))+'px';requestAnimationFrame(()=>{if(active===el)tip.classList.add('ju-help-visible')})}
function schedule(el,x,y){if(!el||!el.getAttribute('data-help')){hide();return}if(pending===el)return;hide();pending=el;anchorX=x;anchorY=y;timer=setTimeout(()=>{timer=null;if(pending!==el||!el.isConnected)return;active=el;show(el)},DELAY)}
function init(){decorate();tip=document.createElement('div');tip.className='ju-help-tooltip';tip.setAttribute('role','tooltip');tip.hidden=true;document.body.append(tip);
 const panel=document.querySelector('.ju-a11y-panel');if(panel){const area=document.createElement('div');area.className='ju-a11y-extra';area.innerHTML=`<strong>Ayudas y visualización</strong><label class="ju-a11y-option"><span>Mostrar todas las ayudas</span><input type="checkbox" role="switch" data-setting="all-help"></label><label class="ju-a11y-option"><span>Invertir colores</span><input type="checkbox" role="switch" data-setting="invert"></label><label class="ju-a11y-option"><span>Blanco y negro</span><input type="checkbox" role="switch" data-setting="grayscale"></label><label class="ju-a11y-option"><span>Subrayar enlaces</span><input type="checkbox" role="switch" data-setting="underline"></label><div class="ju-a11y-font-size"><label for="ju-a11y-font-size">Tamaño de letra <output id="ju-a11y-font-size-output">100 %</output></label><input id="ju-a11y-font-size" type="range" min="100" max="200" step="10" value="100" aria-label="Ampliar únicamente el texto entre el 100 y el 200 por ciento"><button type="button" class="ju-a11y-font-reset">Restablecer letra</button></div><label class="ju-a11y-option"><span>Texto en mayúsculas</span><input type="checkbox" role="switch" data-setting="uppercase"></label><label class="ju-a11y-font">Tipo de letra<select data-setting="font"><option value="original">Original</option><option value="Arial, Helvetica, sans-serif">Arial / Helvetica</option><option value="Verdana, Geneva, sans-serif">Verdana</option><option value="Tahoma, Geneva, sans-serif">Tahoma</option><option value="Georgia, serif">Georgia</option><option value="'Times New Roman', Times, serif">Times New Roman</option><option value="'Courier New', Courier, monospace">Courier New</option><option value="'Trebuchet MS', sans-serif">Trebuchet MS</option></select></label>`;panel.append(area);
 const fontRange=area.querySelector('#ju-a11y-font-size');
 const fontOutput=area.querySelector('#ju-a11y-font-size-output');
 const updateFontSize=(value,persist=true)=>{const n=Math.max(100,Math.min(200,Number(value)||100));fontRange.value=String(n);fontOutput.textContent=n+' %';root.style.setProperty('--ju-font-scale',String(n/100));root.classList.toggle('ju-font-enlarged',n>100);if(persist)save('font-size',String(n));};
 updateFontSize(read('font-size','100'),false);
 fontRange.addEventListener('input',()=>updateFontSize(fontRange.value));
 area.querySelector('.ju-a11y-font-reset').addEventListener('click',()=>updateFontSize(100));
 for(const el of area.querySelectorAll('[data-setting]')){const name=el.dataset.setting;const update=()=>{const value=el.type==='checkbox'?el.checked?'1':'0':el.value;save(name,value);apply(name,value)};const v=read(name,el.type==='checkbox'?'0':'original');if(el.type==='checkbox')el.checked=v==='1';else el.value=[...el.options].some(o=>o.value===v)?v:'original';apply(name,v);el.addEventListener('change',update)} }
 document.addEventListener('pointerover',e=>{if(e.pointerType==='touch')return;const el=e.target.closest?.(actionSelector);if(el&&el!==pending)schedule(el,e.clientX,e.clientY)},true);
 document.addEventListener('pointermove',e=>{if(e.pointerType==='touch')return;const el=e.target.closest?.(actionSelector);if(el!==pending){if(el)schedule(el,e.clientX,e.clientY);else hide();return}if(Math.hypot(e.clientX-anchorX,e.clientY-anchorY)>STILL){schedule(null);schedule(el,e.clientX,e.clientY)}},true);
 document.addEventListener('pointerout',e=>{const el=e.target.closest?.(actionSelector);if(el&&el===pending&&!el.contains(e.relatedTarget))hide()},true);
 document.addEventListener('pointerdown',hide,true);
 document.addEventListener('focusin',e=>{if(e.target.matches?.(actionSelector))schedule(e.target,0,0)},true);
 document.addEventListener('focusout',hide,true);document.addEventListener('scroll',hide,true);
 const observer=new MutationObserver(records=>{for(const rec of records)for(const node of rec.addedNodes)if(node.nodeType===1&&node!==tip)decorate(node)});observer.observe(document.body,{childList:true,subtree:true});
 }
 function apply(name,v){if(name==='font'){if(v==='original')root.style.removeProperty('--ju-accessible-font');else root.style.setProperty('--ju-accessible-font',v);root.classList.toggle('ju-custom-font',v!=='original')}else root.classList.toggle('ju-'+name,v==='1');if(name==='all-help')renderAll(v==='1')}
 let overlays;function renderAll(on){if(overlays){overlays.remove();overlays=null}if(!on)return;overlays=document.createElement('div');overlays.className='ju-all-helps';document.body.append(overlays);const targets=[...document.querySelectorAll(actionSelector)].filter(e=>e.getClientRects().length&&!e.closest('.ju-a11y-panel,.ju-all-helps'));for(const el of targets.slice(0,250)){const r=el.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight||r.right<0||r.left>innerWidth)continue;const item=document.createElement('div');item.className='ju-help-label';item.textContent=el.getAttribute('data-help')||'';item.style.left=Math.max(2,Math.min(innerWidth-190,r.left))+'px';item.style.top=Math.max(2,r.bottom+scrollY)+'px';overlays.append(item)}}
 window.addEventListener('resize',()=>{if(root.classList.contains('ju-all-help'))renderAll(true)});document.addEventListener('scroll',()=>{if(root.classList.contains('ju-all-help'))renderAll(true)},{passive:true});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
