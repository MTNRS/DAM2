#include <json-c/json.h>
#include <set>
#include <mutex>
#include <fstream>
#include <stdexcept>
#include "JocarsaBBDD.hpp"
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <regex>
#include <sstream>
#include <set>
#include <stdexcept>

namespace fs = std::filesystem;

std::string JocarsaSerializador::serializar(const std::vector<std::string>& lista, char delimitador) const {
 std::string out;
 for(size_t i=0;i<lista.size();++i){
  if(i)out+=delimitador;
  const auto& v=lista[i];
  bool quote=v.find_first_of(std::string(1,delimitador)+"\"\r\n")!=std::string::npos || (!v.empty()&&(v.front()==' '||v.back()==' '));
  if(quote)out+='"';
  for(char c:v){if(c=='"')out+='"';out+=c;}
  if(quote)out+='"';
 }
 return out;
}
std::vector<std::string> JocarsaSerializador::desserializar(const std::string& cadena, char delimitador) const {
 std::vector<std::string> r;std::string v;bool quoted=false;
 for(size_t i=0;i<cadena.size();++i){char c=cadena[i];
  if(c=='"' && quoted && i+1<cadena.size() && cadena[i+1]=='"'){v+='"';++i;}
  else if(c=='"' && (quoted || v.empty()))quoted=!quoted;
  else if(c==delimitador && !quoted){r.push_back(v);v.clear();}
  else v+=c;
 }
 if(quoted)throw std::runtime_error("Campo CSV sin cerrar");
 r.push_back(v);return r;
}

JocarsaBBDD::JocarsaBBDD(const std::string& config) {
    // Prioridad: ruta explicita/local -> variable de entorno -> configuracion global.
    std::string rutaConfig = config;
    if (!fs::exists(rutaConfig)) {
        if (const char* env = std::getenv("JOCARSABBDD_CONFIG"); env && fs::exists(env)) rutaConfig = env;
        else if (fs::exists("/etc/jocarsabbdd/config.json")) rutaConfig = "/etc/jocarsabbdd/config.json";
        else throw std::runtime_error("No se ha encontrado config.json ni /etc/jocarsabbdd/config.json");
    }
    std::ifstream f(rutaConfig); if (!f) throw std::runtime_error("No se puede abrir la configuracion: " + rutaConfig);
    std::string s((std::istreambuf_iterator<char>(f)), {});
    std::smatch m;
    if (!std::regex_search(s,m,std::regex("\\\"instalacion\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""))) throw std::runtime_error("Falta 'instalacion' en config.json");
    instalacion=m[1].str();
    if (!std::regex_search(s,m,std::regex("\\\"tamanoRegistro\\\"\\s*:\\s*([0-9]+)"))) throw std::runtime_error("Falta 'tamanoRegistro' en config.json");
    tamanoRegistro=std::stoull(m[1].str());
    fs::create_directories(instalacion);
}
std::string JocarsaBBDD::rutaTabla(const std::string& t,const std::string& e) const { return (fs::path(instalacion)/basededatos/(t+e)).string(); }
std::string JocarsaBBDD::trimDerecha(std::string s){ while(!s.empty() && (s.back()==' '||s.back()=='\n'||s.back()=='\r'||s.back()=='\t')) s.pop_back(); return s; }
bool JocarsaBBDD::creaBaseDatos(const std::string& n){ fs::path p=fs::path(instalacion)/n; if(fs::exists(p)){std::cerr<<"La base de datos ya existe\n";return false;} return fs::create_directory(p); }
bool JocarsaBBDD::usaBaseDatos(const std::string& n){ fs::path p=fs::path(instalacion)/n; if(!fs::exists(p)){std::cerr<<"La base de datos no existe\n";return false;} basededatos=n; return true; }

std::vector<std::string> JocarsaBBDD::listarBases() const {
    std::vector<std::string> out;
    fs::path raiz(instalacion);
    if(!fs::exists(raiz)) return out;
    for(const auto& e : fs::directory_iterator(raiz)){
        if(!e.is_directory()) continue;
        const auto nombre = e.path().filename().string();
        if(nombre.rfind(".txn_", 0) == 0) continue;
        out.push_back(nombre);
    }
    std::sort(out.begin(), out.end());
    return out;
}

std::vector<std::string> JocarsaBBDD::listarTablas() const {
    std::vector<std::string> out;
    if(basededatos.empty()) return out;
    fs::path dir = fs::path(instalacion) / basededatos;
    if(!fs::exists(dir)) return out;
    for(const auto& e : fs::directory_iterator(dir)){
        if(!e.is_regular_file() || e.path().extension() != ".esquema") continue;
        const auto tabla = e.path().stem().string();
        if(fs::exists(dir / (tabla + ".csv"))) out.push_back(tabla);
    }
    std::sort(out.begin(), out.end());
    return out;
}

static std::string tipoNombre(TipoDato t){
    switch(t){case TipoDato::ENTERO:return "ENTERO";case TipoDato::REAL:return "REAL";case TipoDato::BOOLEANO:return "BOOLEANO";case TipoDato::FECHA:return "FECHA";case TipoDato::DECIMAL:return "DECIMAL";default:return "TEXTO";}
}
static TipoDato tipoDesdeNombre(std::string s){
    std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return std::toupper(c);});
    if(s=="ENTERO"||s=="INT") return TipoDato::ENTERO;
    if(s=="REAL"||s=="FLOAT") return TipoDato::REAL;
    if(s=="BOOLEANO"||s=="BOOL") return TipoDato::BOOLEANO;
    if(s=="FECHA"||s=="DATE") return TipoDato::FECHA;
    if(s=="DECIMAL"||s=="NUMERICO") return TipoDato::DECIMAL;
    return TipoDato::TEXTO;
}
bool JocarsaBBDD::validarTipo(TipoDato t,const std::string& v) const{
    if(v.empty()||v=="__JOCARSA_NULL__") return true;
    try{
        size_t n=0;
        if(t==TipoDato::ENTERO){std::stoll(v,&n);return n==v.size();}
        if(t==TipoDato::REAL||t==TipoDato::DECIMAL){std::stod(v,&n);return n==v.size();}
        if(t==TipoDato::BOOLEANO){std::string x=v;std::transform(x.begin(),x.end(),x.begin(),[](unsigned char c){return std::toupper(c);});return x=="1"||x=="0"||x=="VERDADERO"||x=="FALSO"||x=="TRUE"||x=="FALSE";}
        if(t==TipoDato::FECHA){if(v.size()!=10||v[4]!='-'||v[7]!='-')return false;int y=std::stoi(v.substr(0,4)),m=std::stoi(v.substr(5,2)),d=std::stoi(v.substr(8,2));(void)y;return m>=1&&m<=12&&d>=1&&d<=31;}
        return true;
    }catch(...){return false;}
}
std::string JocarsaBBDD::normalizarTipo(TipoDato t,const std::string& v) const{
    std::string up=v;std::transform(up.begin(),up.end(),up.begin(),[](unsigned char c){return std::toupper(c);});
    if(up=="NULL") return "__JOCARSA_NULL__";
    if(t!=TipoDato::BOOLEANO||v.empty()) return v;
    std::string x=v;std::transform(x.begin(),x.end(),x.begin(),[](unsigned char c){return std::toupper(c);});
    return (x=="1"||x=="VERDADERO"||x=="TRUE")?"1":"0";
}
std::map<std::string,TipoDato> JocarsaBBDD::obtenerTipos(const std::string& t) const{
    std::map<std::string,TipoDato> r; for(const auto& c:obtenerEsquema(t)) r[c]=TipoDato::TEXTO;
    r["id"]=TipoDato::ENTERO; r["activo"]=TipoDato::BOOLEANO;
    std::ifstream f(rutaTabla(t,".tipos")); std::string l;
    while(std::getline(f,l)){auto q=l.find(',');if(q!=std::string::npos)r[l.substr(0,q)]=tipoDesdeNombre(l.substr(q+1));}
    return r;
}
bool JocarsaBBDD::creaTablaTipada(const std::string& n,const std::vector<DefinicionColumna>& cols){
    std::string e;for(size_t i=0;i<cols.size();++i){if(i)e+=",";e+=cols[i].nombre;}
    if(!creaTabla(n,e))return false;
    std::ofstream f(rutaTabla(n,".tipos"),std::ios::trunc);f<<"id,ENTERO\nactivo,BOOLEANO\n";for(const auto&c:cols)f<<c.nombre<<","<<tipoNombre(c.tipo)<<"\n";return bool(f);
}
bool JocarsaBBDD::esVista(const std::string& n) const{return !basededatos.empty()&&fs::exists(fs::path(instalacion)/basededatos/(n+".vista"));}
std::string JocarsaBBDD::consultaVista(const std::string& n) const{std::ifstream f(fs::path(instalacion)/basededatos/(n+".vista"));return std::string((std::istreambuf_iterator<char>(f)),{});}
bool JocarsaBBDD::crearVista(const std::string& n,const std::string& q){
    if(basededatos.empty()||n.empty()||q.empty())return false;try{(void)consultar(q);}catch(const std::exception&e){std::cerr<<"Vista invalida: "<<e.what()<<"\n";return false;}
    std::ofstream f(fs::path(instalacion)/basededatos/(n+".vista"),std::ios::trunc);f<<q;return bool(f);
}
bool JocarsaBBDD::eliminarVista(const std::string& n){auto p=fs::path(instalacion)/basededatos/(n+".vista");return fs::exists(p)&&fs::remove(p);}
std::vector<std::string> JocarsaBBDD::listarVistas() const{std::vector<std::string>r;if(basededatos.empty())return r;for(auto&e:fs::directory_iterator(fs::path(instalacion)/basededatos))if(e.path().extension()==".vista")r.push_back(e.path().stem().string());std::sort(r.begin(),r.end());return r;}

std::vector<IndiceSecundario> JocarsaBBDD::listarIndices(const std::string&t) const{
    std::vector<IndiceSecundario> r;std::ifstream f(rutaTabla(t,".indices"));std::string l;while(std::getline(f,l)){auto q=l.find(',');if(q!=std::string::npos)r.push_back({l.substr(0,q),l.substr(q+1)});}return r;
}
void JocarsaBBDD::reconstruirIndices(const std::string&t) const{
    for(const auto&i:listarIndices(t)){std::ofstream f(rutaTabla(t,".sidx_"+i.nombre),std::ios::trunc);for(const auto&r:listarTodo(t)){auto it=r.find(i.columna);if(it!=r.end())f<<std::quoted(it->second)<<","<<r.at("id")<<"\n";}}
}
bool JocarsaBBDD::crearIndice(const std::string&n,const std::string&t,const std::string&c){
    auto es=obtenerEsquema(t);if(std::find(es.begin(),es.end(),c)==es.end())return false;for(const auto&i:listarIndices(t))if(i.nombre==n)return false;
    std::ofstream(rutaTabla(t,".indices"),std::ios::app)<<n<<","<<c<<"\n";reconstruirIndices(t);return true;
}
bool JocarsaBBDD::eliminarIndice(const std::string&n,const std::string&t){
    auto is=listarIndices(t);bool ok=false;std::ofstream f(rutaTabla(t,".indices"),std::ios::trunc);for(const auto&i:is)if(i.nombre==n)ok=true;else f<<i.nombre<<","<<i.columna<<"\n";
    std::error_code ec;fs::remove(rutaTabla(t,".sidx_"+n),ec);return ok;
}
std::vector<long long> JocarsaBBDD::buscarIdsIndice(const std::string&t,const std::string&c,const std::string&v) const{
    for(const auto&i:listarIndices(t))if(i.columna==c){std::vector<long long> ids;std::ifstream f(rutaTabla(t,".sidx_"+i.nombre));std::string val;char coma;long long id;while(f>>std::quoted(val)>>coma>>id)if(val==v)ids.push_back(id);return ids;}return {};
}
std::string JocarsaBBDD::explicar(const std::string&q) const{
    std::string up=q;std::transform(up.begin(),up.end(),up.begin(),[](unsigned char c){return std::toupper(c);});
    std::string tabla,col,op;auto de=up.find(" DE ");if(de!=std::string::npos){size_t a=de+4,b=q.find_first_of(" \t\r\n",a);tabla=q.substr(a,b==std::string::npos?q.size()-a:b-a);}
    auto dw=up.find(" DONDE ");if(dw!=std::string::npos){size_t a=dw+7,b=q.find_first_of(" =<>!\t\r\n",a);col=q.substr(a,b-a);if(b!=std::string::npos){while(b<q.size()&&std::isspace((unsigned char)q[b]))++b;if(b<q.size())op=std::string(1,q[b]);}}
    std::ostringstream o;o<<"PLAN DE EJECUCION\nFUENTE: "<<(tabla.empty()?"?":tabla)<<"\n";
    bool ix=false;std::string nom;if(op=="=")for(const auto&i:listarIndices(tabla))if(i.columna==col){ix=true;nom=i.nombre;break;}
    if(ix)o<<"METODO: INDEX SCAN\nINDICE: "<<nom<<"\nCOLUMNA: "<<col<<"\n";else o<<"METODO: TABLE SCAN\n";
    if(esVista(tabla))o<<"FUENTE TIPO: VISTA\n";else o<<"FUENTE TIPO: TABLA\n";return o.str();
}

bool JocarsaBBDD::iniciarTransaccion(){
    if(transaccionActiva||basededatos.empty())return false;baseTransaccion=basededatos;rutaSnapshot=fs::path(instalacion)/(".txn_"+basededatos);
    std::error_code ec;fs::remove_all(rutaSnapshot,ec);fs::create_directories(rutaSnapshot);
    auto src=fs::path(instalacion)/basededatos;for(auto&e:fs::directory_iterator(src))if(e.is_regular_file())fs::copy_file(e.path(),rutaSnapshot/e.path().filename(),fs::copy_options::overwrite_existing);
    transaccionActiva=true;return true;
}
bool JocarsaBBDD::confirmarTransaccion(){if(!transaccionActiva)return false;std::error_code ec;fs::remove_all(rutaSnapshot,ec);transaccionActiva=false;baseTransaccion.clear();return true;}
bool JocarsaBBDD::deshacerTransaccion(){
    if(!transaccionActiva)return false;auto dst=fs::path(instalacion)/baseTransaccion;std::error_code ec;
    for(auto&e:fs::directory_iterator(dst))if(e.is_regular_file())fs::remove(e.path(),ec);
    for(auto&e:fs::directory_iterator(rutaSnapshot))if(e.is_regular_file())fs::copy_file(e.path(),dst/e.path().filename(),fs::copy_options::overwrite_existing);
    fs::remove_all(rutaSnapshot,ec);basededatos=baseTransaccion;transaccionActiva=false;baseTransaccion.clear();return true;
}

bool JocarsaBBDD::creaTabla(const std::string& n,const std::string& e){ if(basededatos.empty()){std::cerr<<"No hay base seleccionada\n";return false;} auto csv=rutaTabla(n,".csv"); if(fs::exists(csv)){std::cerr<<"La tabla ya existe\n";return false;} std::ofstream(csv,std::ios::binary); std::ofstream(rutaTabla(n,".esquema"))<<"id,activo,"<<e; std::ofstream(rutaTabla(n,".idx")); std::ofstream(rutaTabla(n,".rel"))<<"PK,id\n"; std::ofstream tf(rutaTabla(n,".tipos")); tf<<"id,ENTERO\nactivo,BOOLEANO\n"; for(const auto&c:JocarsaSerializador().desserializar(e)) if(!c.empty()) tf<<c<<",TEXTO\n"; return true; }

bool JocarsaBBDD::alteraTablaAnadir(const std::string& t,const std::string& col){
    auto es=obtenerEsquema(t); if(es.empty()||col.empty()) return false;
    if(std::find(es.begin(),es.end(),col)!=es.end()){std::cerr<<"La columna ya existe\n";return false;}
    auto filas=listarTodo(t); es.push_back(col);
    std::ofstream(rutaTabla(t,".esquema"),std::ios::trunc)<<JocarsaSerializador().serializar(es);
    std::ofstream csv(rutaTabla(t,".csv"),std::ios::binary|std::ios::trunc); std::ofstream idx(rutaTabla(t,".idx"),std::ios::trunc);
    for(const auto&r:filas){ std::vector<std::string> e; for(size_t i=0;i<es.size()-1;++i)e.push_back(r.at(es[i])); e.push_back(""); auto pos=csv.tellp(); auto reg=prepararRegistro(e); csv.write(reg.data(),reg.size()); idx<<e[0]<<","<<pos<<"\n"; }
    return bool(csv)&&bool(idx);
}

bool JocarsaBBDD::alteraTablaEliminarColumna(const std::string& t,const std::string& col){
    if(col=="id"||col=="activo"){std::cerr<<"No se puede eliminar una columna interna\n";return false;}
    auto es=obtenerEsquema(t); auto it=std::find(es.begin(),es.end(),col); if(it==es.end()) return false;
    auto filas=listarTodo(t); es.erase(it);
    std::ofstream(rutaTabla(t,".esquema"),std::ios::trunc)<<JocarsaSerializador().serializar(es);
    std::ofstream csv(rutaTabla(t,".csv"),std::ios::binary|std::ios::trunc); std::ofstream idx(rutaTabla(t,".idx"),std::ios::trunc);
    for(const auto&r:filas){ std::vector<std::string> e; for(const auto&c:es)e.push_back(r.at(c)); auto pos=csv.tellp(); auto reg=prepararRegistro(e); csv.write(reg.data(),reg.size()); idx<<e[0]<<","<<pos<<"\n"; }
    return bool(csv)&&bool(idx);
}

bool JocarsaBBDD::alteraTablaRenombrarColumna(const std::string& t,const std::string& antigua,const std::string& nueva){
    if(antigua=="id"||antigua=="activo"||nueva.empty()) return false;
    auto es=obtenerEsquema(t); auto it=std::find(es.begin(),es.end(),antigua); if(it==es.end()) return false;
    if(std::find(es.begin(),es.end(),nueva)!=es.end()){std::cerr<<"La columna destino ya existe\n";return false;}
    *it=nueva; std::ofstream f(rutaTabla(t,".esquema"),std::ios::trunc); f<<JocarsaSerializador().serializar(es); return bool(f);
}

bool JocarsaBBDD::alteraTablaModificarColumna(const std::string& t,const std::string& antigua,const std::string& nueva){
    return alteraTablaRenombrarColumna(t,antigua,nueva);
}

bool JocarsaBBDD::truncarTabla(const std::string& t){
    if(basededatos.empty()||!fs::exists(rutaTabla(t,".csv"))) return false;
    std::ofstream csv(rutaTabla(t,".csv"),std::ios::binary|std::ios::trunc); std::ofstream idx(rutaTabla(t,".idx"),std::ios::trunc); return bool(csv)&&bool(idx);
}


namespace {
std::mutex mutexColecciones;
using Asociaciones = std::map<std::string,std::set<std::string>>;
bool nombreValido(const std::string& n){if(n.empty()||n.size()>128)return false;for(unsigned char c:n)if(!std::isalnum(c)&&c!='_'&&c!='-')return false;return n!="."&&n!="..";}
std::filesystem::path rutaColecciones(const JocarsaBBDD& db){return std::filesystem::path(db.instalacion)/db.basededatos/".colecciones.json";}
Asociaciones leerColecciones(const JocarsaBBDD& db){
 Asociaciones r;auto path=rutaColecciones(db);if(!std::filesystem::exists(path))return r;
 json_object* obj=json_object_from_file(path.string().c_str());if(!obj)throw std::runtime_error("Metadatos de colecciones invalidos");
 if(!json_object_is_type(obj,json_type_object)){json_object_put(obj);throw std::runtime_error("Formato de colecciones invalido");}
 json_object_object_foreach(obj,k,v){if(!json_object_is_type(v,json_type_array)){json_object_put(obj);throw std::runtime_error("Coleccion invalida");}auto& a=r[k];for(int i=0;i<json_object_array_length(v);i++){auto* x=json_object_array_get_idx(v,i);if(json_object_is_type(x,json_type_string))a.insert(json_object_get_string(x));}}
 json_object_put(obj);return r;
}
void guardarColecciones(const JocarsaBBDD& db,const Asociaciones& a){
 auto path=rutaColecciones(db);auto temp=path;temp+=".tmp";
 json_object* obj=json_object_new_object();for(auto& [name,tables]:a){auto* ar=json_object_new_array();for(auto& t:tables)json_object_array_add(ar,json_object_new_string(t.c_str()));json_object_object_add(obj,name.c_str(),ar);}
 const char* json=json_object_to_json_string_ext(obj,JSON_C_TO_STRING_PRETTY);
 {std::ofstream out(temp,std::ios::binary|std::ios::trunc);if(!out){json_object_put(obj);throw std::runtime_error("No se pueden guardar colecciones");}out<<json;out.flush();if(!out){json_object_put(obj);throw std::runtime_error("Error escribiendo colecciones");}}
 json_object_put(obj);std::filesystem::rename(temp,path);
}
}
bool JocarsaBBDD::eliminarTabla(const std::string& t){
    if(basededatos.empty()) return false; bool habia=false;
    for(const auto&e:{".csv",".esquema",".idx",".rel",".tipos",".indices"}){auto p=rutaTabla(t,e);if(fs::exists(p)){fs::remove(p);habia=true;}}
    if(habia){std::lock_guard<std::mutex> l(mutexColecciones);auto a=leerColecciones(*this);for(auto& [n,ts]:a)ts.erase(t);guardarColecciones(*this,a);}
    return habia;
}

bool JocarsaBBDD::eliminarBaseDatos(const std::string& n){
    if(n.empty()) return false; fs::path p=fs::path(instalacion)/n; if(!fs::exists(p)||!fs::is_directory(p)) return false;
    fs::remove_all(p); if(basededatos==n) basededatos.clear(); return true;
}
std::string JocarsaBBDD::obtenerClavePrimaria(const std::string& t) const {
    // Compatibilidad: toda tabla JocarsaBBDD tiene id como PK implicita.
    auto es=obtenerEsquema(t);
    return es.empty() ? "" : "id";
}

std::vector<ClaveForanea> JocarsaBBDD::obtenerClavesForaneas(const std::string& t) const {
    std::vector<ClaveForanea> out;
    std::ifstream f(rutaTabla(t,".rel"));
    std::string linea;
    while(std::getline(f,linea)){
        auto v=JocarsaSerializador().desserializar(linea);
        if(v.size()==4 && v[0]=="FK") out.push_back({v[1],v[2],v[3]});
    }
    return out;
}

RestriccionColumna JocarsaBBDD::obtenerRestricciones(const std::string& t,const std::string& col) const {
    RestriccionColumna r; std::ifstream f(rutaTabla(t,".rel")); std::string linea;
    while(std::getline(f,linea)){
        auto v=JocarsaSerializador().desserializar(linea);
        if(v.size()>=2 && v[1]==col){
            if(v[0]=="NN") r.noNulo=true;
            else if(v[0]=="UQ") r.unico=true;
            else if(v[0]=="DF" && v.size()>=3){r.tieneDefecto=true;r.valorDefecto=v[2];}
        }
    }
    return r;
}

bool JocarsaBBDD::establecerNoNulo(const std::string& t,const std::string& col){
    auto es=obtenerEsquema(t); if(std::find(es.begin(),es.end(),col)==es.end()||col=="activo") return false;
    for(const auto&r:listarTodo(t)) if(r.at(col).empty()){std::cerr<<"No se puede aplicar NO NULO: existen valores vacios\n";return false;}
    if(obtenerRestricciones(t,col).noNulo) return true;
    std::ofstream(rutaTabla(t,".rel"),std::ios::app)<<"NN,"<<col<<"\n"; return true;
}

bool JocarsaBBDD::establecerUnico(const std::string& t,const std::string& col){
    auto es=obtenerEsquema(t); if(std::find(es.begin(),es.end(),col)==es.end()||col=="activo") return false;
    std::set<std::string> vistos; for(const auto&r:listarTodo(t)){auto v=r.at(col);if(!v.empty()&&!vistos.insert(v).second){std::cerr<<"No se puede aplicar UNICO: hay valores duplicados\n";return false;}}
    if(obtenerRestricciones(t,col).unico) return true;
    std::ofstream(rutaTabla(t,".rel"),std::ios::app)<<"UQ,"<<col<<"\n"; return true;
}

bool JocarsaBBDD::establecerPorDefecto(const std::string& t,const std::string& col,const std::string& valor){
    auto es=obtenerEsquema(t); if(std::find(es.begin(),es.end(),col)==es.end()||col=="id"||col=="activo") return false;
    // Reescribe solo la entrada DF de esta columna, conservando el resto de metadatos.
    std::vector<std::string> lineas; std::ifstream in(rutaTabla(t,".rel")); std::string l;
    while(std::getline(in,l)){auto v=JocarsaSerializador().desserializar(l);if(!(v.size()>=2&&v[0]=="DF"&&v[1]==col))lineas.push_back(l);}
    std::ofstream out(rutaTabla(t,".rel"),std::ios::trunc);for(const auto&x:lineas)out<<x<<"\n";out<<"DF,"<<col<<","<<valor<<"\n";return bool(out);
}

bool JocarsaBBDD::prepararYValidarRestricciones(const std::string& t,std::vector<std::string>& datos,long long idIgnorar) const {
    auto es=obtenerEsquema(t); if(es.size()<2||datos.size()!=es.size()-2) return false;
    for(size_t i=2;i<es.size();++i){
        auto rc=obtenerRestricciones(t,es[i]); auto& valor=datos[i-2];
        if(valor.empty()&&rc.tieneDefecto) valor=rc.valorDefecto;
        if(rc.noNulo&&valor.empty()){std::cerr<<"Violacion NO NULO: "<<t<<"."<<es[i]<<"\n";return false;}
        if(rc.unico&&!valor.empty()) for(const auto&r:listarTodo(t)) if(r.at(es[i])==valor && std::stoll(r.at("id"))!=idIgnorar){std::cerr<<"Violacion UNICO: "<<t<<"."<<es[i]<<"="<<valor<<"\n";return false;}
    }
    return true;
}

bool JocarsaBBDD::anadirClaveForanea(const std::string& t,const std::string& col,const std::string& tr,const std::string& cr){
    if(basededatos.empty()) return false;
    auto es=obtenerEsquema(t), er=obtenerEsquema(tr);
    if(es.empty()||er.empty()){std::cerr<<"Tabla local o referenciada no encontrada\n";return false;}
    if(std::find(es.begin(),es.end(),col)==es.end()){std::cerr<<"Columna local no encontrada: "<<col<<"\n";return false;}
    if(std::find(er.begin(),er.end(),cr)==er.end()){std::cerr<<"Columna referenciada no encontrada: "<<cr<<"\n";return false;}
    if(cr!="id"){std::cerr<<"En esta version la FK debe referenciar la PK id\n";return false;}
    for(const auto& fk:obtenerClavesForaneas(t)) if(fk.columna==col){std::cerr<<"La columna ya tiene clave foranea\n";return false;}
    // Los datos existentes tambien deben cumplir la nueva restriccion.
    for(const auto& r:listarTodo(t)){
        auto it=r.find(col); if(it!=r.end()&&!it->second.empty()&&!registroReferenciado(tr,cr,it->second)){
            std::cerr<<"No se puede crear FK: valor existente sin referencia: "<<it->second<<"\n";return false;
        }
    }
    std::ofstream f(rutaTabla(t,".rel"),std::ios::app);
    f<<"FK,"<<col<<","<<tr<<","<<cr<<"\n";
    return bool(f);
}

bool JocarsaBBDD::registroReferenciado(const std::string& t,const std::string& col,const std::string& valor) const {
    if(valor.empty()) return true; // cadena vacia equivale a FK no informada en esta version
    if(col=="id"){
        try { return !seleccionar(t,std::stoll(valor)).empty(); } catch(...) { return false; }
    }
    return !buscarColumna(t,col,valor).empty();
}

bool JocarsaBBDD::validarClavesForaneas(const std::string& t,const std::vector<std::string>& datos) const {
    auto es=obtenerEsquema(t);
    if(es.size()<2||datos.size()!=es.size()-2) return false;
    for(const auto& fk:obtenerClavesForaneas(t)){
        auto it=std::find(es.begin()+2,es.end(),fk.columna);
        if(it==es.end()) return false;
        size_t pos=static_cast<size_t>(it-(es.begin()+2));
        const auto& valor=datos[pos];
        if(!valor.empty()&&!registroReferenciado(fk.tablaReferenciada,fk.columnaReferenciada,valor)){
            std::cerr<<"Violacion de clave foranea: "<<t<<"."<<fk.columna<<"="<<valor
                     <<" no existe en "<<fk.tablaReferenciada<<"."<<fk.columnaReferenciada<<"\n";
            return false;
        }
    }
    return true;
}

bool JocarsaBBDD::puedeEliminarRegistro(const std::string& t,const std::map<std::string,std::string>& registro) const {
    if(basededatos.empty()) return false;
    fs::path dir=fs::path(instalacion)/basededatos;
    if(!fs::exists(dir)) return false;
    for(const auto& entry:fs::directory_iterator(dir)){
        if(entry.path().extension()!=".rel") continue;
        std::string hija=entry.path().stem().string();
        for(const auto& fk:obtenerClavesForaneas(hija)){
            if(fk.tablaReferenciada!=t) continue;
            auto it=registro.find(fk.columnaReferenciada);
            if(it==registro.end()) continue;
            if(!buscarColumna(hija,fk.columna,it->second).empty()){
                std::cerr<<"No se puede eliminar: registro referenciado desde "<<hija<<"."<<fk.columna<<"\n";
                return false;
            }
        }
    }
    return true;
}

std::vector<std::string> JocarsaBBDD::obtenerEsquema(const std::string& t) const { std::ifstream f(rutaTabla(t,".esquema")); if(!f) return {}; std::string s((std::istreambuf_iterator<char>(f)),{}); return JocarsaSerializador().desserializar(s); }
long long JocarsaBBDD::siguienteId(const std::string& t) const { std::ifstream f(rutaTabla(t,".idx")); long long ultimo=0,id,pos; char c; while(f>>id>>c>>pos) ultimo=id; return ultimo+1; }
std::string JocarsaBBDD::prepararRegistro(const std::vector<std::string>& e) const { auto s=JocarsaSerializador().serializar(e); if(s.size()>tamanoRegistro-1) throw std::runtime_error("Registro demasiado grande"); s.append(tamanoRegistro-1-s.size(),' '); s.push_back('\n'); return s; }
long long JocarsaBBDD::insertarDatos(const std::string& t,const std::vector<std::string>& entrada){
    if(basededatos.empty()||!fs::exists(rutaTabla(t,".csv"))) return -1;
    auto es=obtenerEsquema(t); std::vector<std::string> datos=entrada;
    if(es.size()<2||datos.size()!=es.size()-2){std::cerr<<"Numero de valores incorrecto\n";return -1;}
    auto tipos=obtenerTipos(t); for(size_t i=0;i<datos.size();++i){auto tipo=tipos[es[i+2]];datos[i]=normalizarTipo(tipo,datos[i]);if(!validarTipo(tipo,datos[i])){std::cerr<<"Tipo invalido para "<<es[i+2]<<": "<<datos[i]<<" (esperado "<<tipoNombre(tipo)<<")\n";return -1;}} if(!prepararYValidarRestricciones(t,datos)||!validarClavesForaneas(t,datos)) return -1;
    auto id=siguienteId(t); std::vector<std::string> e={std::to_string(id),"1"}; e.insert(e.end(),datos.begin(),datos.end());
    auto reg=prepararRegistro(e); std::ofstream f(rutaTabla(t,".csv"),std::ios::binary|std::ios::app); auto pos=fs::file_size(rutaTabla(t,".csv"));
    f.write(reg.data(),reg.size()); if(!f) return -1; std::ofstream(rutaTabla(t,".idx"),std::ios::app)<<id<<","<<pos<<"\n"; reconstruirIndices(t); return id;
}
std::int64_t JocarsaBBDD::buscarPosicion(const std::string& t,long long buscado) const { std::ifstream f(rutaTabla(t,".idx")); long long id,pos; char c; while(f>>id>>c>>pos) if(id==buscado) return pos; return -1; }
std::vector<std::string> JocarsaBBDD::leerRegistro(const std::string& t,long long id) const { auto pos=buscarPosicion(t,id); if(pos<0)return{}; std::ifstream f(rutaTabla(t,".csv"),std::ios::binary); f.seekg(pos); std::string b(tamanoRegistro,'\0'); f.read(b.data(),tamanoRegistro); b.resize(f.gcount()); auto e=JocarsaSerializador().desserializar(trimDerecha(b)); if(e.size()<2||e[1]=="0")return{}; return e; }
std::map<std::string,std::string> JocarsaBBDD::seleccionar(const std::string& t,long long id) const { auto e=leerRegistro(t,id), es=obtenerEsquema(t); std::map<std::string,std::string> r; if(e.size()!=es.size())return r; for(size_t i=0;i<es.size();++i)r[es[i]]=e[i]; return r; }
std::vector<std::map<std::string,std::string>> JocarsaBBDD::listarTodo(const std::string& t) const { std::vector<std::map<std::string,std::string>> out; auto es=obtenerEsquema(t); std::ifstream f(rutaTabla(t,".csv"),std::ios::binary); while(f){std::string b(tamanoRegistro,'\0');f.read(b.data(),tamanoRegistro);if(f.gcount()==0)break;b.resize(f.gcount());auto e=JocarsaSerializador().desserializar(trimDerecha(b));if(e.size()==es.size()&&e.size()>1&&e[1]=="1"){std::map<std::string,std::string> r;for(size_t i=0;i<es.size();++i)r[es[i]]=e[i];out.push_back(r);}}return out; }
std::vector<std::map<std::string,std::string>> JocarsaBBDD::buscarColumna(const std::string& t,const std::string& col,const std::string& val) const { auto es=obtenerEsquema(t); auto it=std::find(es.begin(),es.end(),col); if(it==es.end())return{}; std::vector<std::map<std::string,std::string>> out;for(const auto&i:listarIndices(t))if(i.columna==col){for(auto id:buscarIdsIndice(t,col,val)){auto r=seleccionar(t,id);if(!r.empty())out.push_back(r);}return out;}size_t p=it-es.begin();for(auto&r:listarTodo(t)) if(r.at(es[p])==val) out.push_back(r); return out; }
bool JocarsaBBDD::actualizar(const std::string& t,long long id,const std::vector<std::string>& datos){
    auto pos=buscarPosicion(t,id); auto es=obtenerEsquema(t);
    if(pos<0||leerRegistro(t,id).empty()||datos.size()!=es.size()-2) return false;
    std::vector<std::string> validados=datos; auto tipos=obtenerTipos(t);for(size_t i=0;i<validados.size();++i){auto tipo=tipos[es[i+2]];validados[i]=normalizarTipo(tipo,validados[i]);if(!validarTipo(tipo,validados[i])){std::cerr<<"Tipo invalido para "<<es[i+2]<<"\n";return false;}} if(!prepararYValidarRestricciones(t,validados,id)||!validarClavesForaneas(t,validados)) return false;
    std::vector<std::string> e={std::to_string(id),"1"}; e.insert(e.end(),validados.begin(),validados.end()); auto reg=prepararRegistro(e);
    std::fstream f(rutaTabla(t,".csv"),std::ios::binary|std::ios::in|std::ios::out); f.seekp(pos); f.write(reg.data(),reg.size()); bool ok=bool(f); if(ok)reconstruirIndices(t); return ok;
}
/*OLD*/
#if 0
    std::vector<std::string> e={std::to_string(id),"1"}; e.insert(e.end(),datos.begin(),datos.end()); auto reg=prepararRegistro(e);
    std::fstream f(rutaTabla(t,".csv"),std::ios::binary|std::ios::in|std::ios::out); f.seekp(pos); f.write(reg.data(),reg.size()); return bool(f);
}
#endif
bool JocarsaBBDD::eliminar(const std::string& t,long long id){
    auto pos=buscarPosicion(t,id); auto e=leerRegistro(t,id); if(pos<0||e.empty()) return false;
    auto registro=seleccionar(t,id); if(!puedeEliminarRegistro(t,registro)) return false;
    e[1]="0"; auto reg=prepararRegistro(e); std::fstream f(rutaTabla(t,".csv"),std::ios::binary|std::ios::in|std::ios::out); f.seekp(pos); f.write(reg.data(),reg.size()); return bool(f);
}

long long JocarsaBBDD::insertarConColumnas(const std::string& t,const std::vector<std::string>& columnas,const std::vector<std::string>& valores){
    auto es=obtenerEsquema(t); if(es.size()<2||columnas.size()!=valores.size()) return -1;
    std::vector<std::string> datos(es.size()-2,"");
    for(size_t i=0;i<columnas.size();++i){
        auto it=std::find(es.begin()+2,es.end(),columnas[i]);
        if(it==es.end()){std::cerr<<"Columna no encontrada: "<<columnas[i]<<"\n";return -1;}
        datos[static_cast<size_t>(it-(es.begin()+2))]=valores[i];
    }
    return insertarDatos(t,datos);
}

long long JocarsaBBDD::insertarDesdeSeleccion(const std::string& destino,const std::string& origen){
    auto ed=obtenerEsquema(destino), eo=obtenerEsquema(origen);
    if(ed.size()<2||eo.size()<2||ed.size()!=eo.size()){std::cerr<<"Los esquemas no son compatibles\n";return -1;}
    long long n=0;
    for(const auto&r:listarTodo(origen)){
        std::vector<std::string> datos;
        for(size_t i=2;i<eo.size();++i) datos.push_back(r.at(eo[i]));
        if(insertarDatos(destino,datos)<0) return -1;
        ++n;
    }
    return n;
}

long long JocarsaBBDD::actualizarDonde(const std::string& t,const std::map<std::string,std::string>& cambios,const std::string& colDonde,const std::string& valDonde){
    auto es=obtenerEsquema(t); if(es.size()<2||cambios.empty()) return -1;
    for(const auto&[c,v]:cambios){(void)v;if(c=="id"||c=="activo"||std::find(es.begin(),es.end(),c)==es.end()){std::cerr<<"Columna no modificable: "<<c<<"\n";return -1;}}
    if(!colDonde.empty()&&std::find(es.begin(),es.end(),colDonde)==es.end()){std::cerr<<"Columna WHERE/DONDE no encontrada\n";return -1;}
    long long n=0;
    auto filas=listarTodo(t);
    for(auto&r:filas){
        if(!colDonde.empty() && r.at(colDonde)!=valDonde) continue;
        std::vector<std::string> datos;
        for(size_t i=2;i<es.size();++i){auto it=cambios.find(es[i]);datos.push_back(it==cambios.end()?r.at(es[i]):it->second);}
        if(actualizar(t,std::stoll(r.at("id")),datos)) ++n;
    }
    return n;
}

long long JocarsaBBDD::eliminarDonde(const std::string& t,const std::string& colDonde,const std::string& valDonde){
    auto es=obtenerEsquema(t); if(es.size()<2) return -1;
    if(!colDonde.empty()&&std::find(es.begin(),es.end(),colDonde)==es.end()){std::cerr<<"Columna WHERE/DONDE no encontrada\n";return -1;}
    long long n=0;
    auto filas=listarTodo(t);
    for(const auto&r:filas){
        if(!colDonde.empty() && r.at(colDonde)!=valDonde) continue;
        if(eliminar(t,std::stoll(r.at("id")))) ++n;
    }
    return n;
}

// -----------------------------------------------------------------------------
// DQL: SELECCIONAR ... DE ...
// Subconjunto implementado: DISTINTO, COMO (alias y LIKE), DONDE, = <> != > <
// >= <=, Y/O/NO, ENTRE, EN, ORDENAR POR, ASCENDENTE/DESCENDENTE y LIMITE.
// -----------------------------------------------------------------------------
namespace {
struct TokenDQL { std::string texto; bool literal=false; };
static std::string dqlMayus(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return std::toupper(c);});return s;}
static bool dqlNumero(const std::string&s,double&v){char*e=nullptr;v=std::strtod(s.c_str(),&e);return e&&*e=='\0'&&e!=s.c_str();}
static int dqlComparar(const std::string&a,const std::string&b){double x,y;if(dqlNumero(a,x)&&dqlNumero(b,y))return x<y?-1:(x>y?1:0);return a<b?-1:(a>b?1:0);}
static std::vector<TokenDQL> dqlTokens(const std::string&s){
 std::vector<TokenDQL> r; size_t i=0;
 while(i<s.size()){
  if(std::isspace((unsigned char)s[i])||s[i]==';'){++i;continue;}
  if(s[i]=='\''||s[i]=='"'){char q=s[i++];std::string v;while(i<s.size()){if(s[i]==q){if(i+1<s.size()&&s[i+1]==q){v+=q;i+=2;continue;}++i;break;}v+=s[i++];}r.push_back({v,true});continue;}
  if(std::string("(),*").find(s[i])!=std::string::npos){r.push_back({std::string(1,s[i++]),false});continue;}
  if(std::string("=<>!").find(s[i])!=std::string::npos){std::string v(1,s[i++]);if(i<s.size()&&(s[i]=='='||(v=="<"&&s[i]=='>')))v+=s[i++];r.push_back({v,false});continue;}
  std::string v;while(i<s.size()&&!std::isspace((unsigned char)s[i])&&std::string("(),;*=<>!\"'").find(s[i])==std::string::npos)v+=s[i++];
  if(!v.empty())r.push_back({v,false});
 }
 return r;
}
class ExprDQL {
 const std::vector<TokenDQL>&t; size_t p=0; const std::map<std::string,std::string>&f;
 bool kw(const std::string&x)const{return p<t.size()&&!t[p].literal&&dqlMayus(t[p].texto)==x;}
 bool tomar(const std::string&x){if(kw(x)){++p;return true;}return false;}
 std::string valor(){if(p>=t.size())throw std::runtime_error("Falta un valor en DONDE");auto x=t[p++];if(!x.literal){auto it=f.find(x.texto);if(it!=f.end())return it->second;}return x.texto;}
 bool prim(){
  if(p<t.size()&&t[p].texto=="("){++p;bool v=o();if(p>=t.size()||t[p].texto!=")")throw std::runtime_error("Falta ')' en DONDE");++p;return v;}
  std::string izq=valor(); bool neg=tomar("NO");
  if(tomar("ENTRE")){std::string a=valor();if(!tomar("Y"))throw std::runtime_error("ENTRE necesita Y");std::string b=valor();bool v=dqlComparar(izq,a)>=0&&dqlComparar(izq,b)<=0;return neg?!v:v;}
  if(tomar("EN")){if(p>=t.size()||t[p++].texto!="(")throw std::runtime_error("EN necesita '('");bool v=false;while(p<t.size()&&t[p].texto!=")"){if(izq==valor())v=true;if(p<t.size()&&t[p].texto==",")++p;else break;}if(p>=t.size()||t[p++].texto!=")")throw std::runtime_error("EN necesita ')'");return neg?!v:v;}
  if(tomar("COMO")||tomar("LIKE")){std::string patron=valor(), rx="^";for(char c:patron){if(c=='%')rx+=".*";else if(c=='_')rx+='.';else{if(std::string(".^$|()[]{}*+?\\").find(c)!=std::string::npos)rx+='\\';rx+=c;}}rx+="$";bool v=std::regex_match(izq,std::regex(rx));return neg?!v:v;}
  if(neg) throw std::runtime_error("NO debe preceder una condicion, ENTRE, EN o COMO");
  if(p>=t.size())throw std::runtime_error("Falta operador de comparacion");std::string op=t[p++].texto;std::string der=valor();int c=dqlComparar(izq,der);
  if(op=="=")return c==0;if(op=="<>"||op=="!=")return c!=0;if(op==">")return c>0;if(op=="<")return c<0;if(op==">=")return c>=0;if(op=="<=")return c<=0;throw std::runtime_error("Operador no soportado: "+op);
 }
 bool no(){if(tomar("NO"))return !no();return prim();}
 bool y(){bool v=no();while(tomar("Y")){bool d=no();v=v&&d;}return v;}
 bool o(){bool v=y();while(tomar("O")){bool d=y();v=v||d;}return v;}
public: ExprDQL(const std::vector<TokenDQL>&tt,const std::map<std::string,std::string>&ff):t(tt),f(ff){} bool evaluar(){if(t.empty())return true;bool v=o();if(p!=t.size())throw std::runtime_error("Expresion DONDE no reconocida cerca de: "+t[p].texto);return v;}
};
struct CampoDQL{
 std::string nombre,alias,funcion;
 bool agregado() const { return !funcion.empty(); }
};
static std::string dqlNumeroTexto(double v){
 std::ostringstream o; o<<std::setprecision(15)<<v; std::string s=o.str();
 if(s.find('.')!=std::string::npos){while(!s.empty()&&s.back()=='0')s.pop_back();if(!s.empty()&&s.back()=='.')s.pop_back();}
 return s;
}
}

ResultadoConsulta JocarsaBBDD::consultarInterno(const std::string& consulta, int profundidad) const {
    auto t=dqlTokens(consulta); size_t p=0;
    auto kw=[&](const std::string&x){return p<t.size()&&!t[p].literal&&dqlMayus(t[p].texto)==x;};
    auto toma=[&](const std::string&x){if(kw(x)){++p;return true;}return false;};
    if(!toma("SELECCIONAR")) throw std::runtime_error("La consulta debe comenzar por SELECCIONAR");
    bool distinto=toma("DISTINTO");
    std::vector<CampoDQL> campos; bool estrella=false;
    if(p<t.size()&&t[p].texto=="*"){estrella=true;++p;}
    else while(p<t.size()&&!kw("DE")){
        CampoDQL c;
        std::string posible=dqlMayus(t[p].texto);
        if((posible=="CONTAR"||posible=="SUMA"||posible=="MEDIA"||posible=="MINIMO"||posible=="MAXIMO") && p+1<t.size() && t[p+1].texto=="("){
            c.funcion=posible; p+=2;
            if(p>=t.size()) throw std::runtime_error("Falta argumento de funcion agregada");
            c.nombre=t[p++].texto;
            if(p>=t.size()||t[p++].texto!=")") throw std::runtime_error("Falta ')' en funcion agregada");
            c.alias=c.funcion+"("+c.nombre+")";
        } else { c.nombre=t[p++].texto; c.alias=c.nombre; }
        if(toma("COMO")){if(p>=t.size())throw std::runtime_error("Falta alias tras COMO");c.alias=t[p++].texto;}
        campos.push_back(c);
        if(p<t.size()&&t[p].texto==","){++p;continue;}
        if(!kw("DE")) throw std::runtime_error("Se esperaba ',' o DE");
    }
    if(!toma("DE")||p>=t.size()) throw std::runtime_error("Falta DE tabla");
    std::string tablaBase=t[p++].texto; std::string aliasBase=tablaBase;
    auto esClausula=[&](size_t z){if(z>=t.size()||t[z].literal)return false;auto u=dqlMayus(t[z].texto);return u=="JOIN"||u=="UNIR"||u=="LEFT"||u=="IZQUIERDA"||u=="RIGHT"||u=="DERECHA"||u=="FULL"||u=="COMPLETO"||u=="CROSS"||u=="CRUZADO"||u=="DONDE"||u=="AGRUPAR"||u=="TENIENDO"||u=="ORDENAR"||u=="LIMITE";};
    if(p<t.size()&&!esClausula(p)){if(kw("COMO")){++p;if(p>=t.size())throw std::runtime_error("Falta alias");aliasBase=t[p++].texto;}else aliasBase=t[p++].texto;}
    std::vector<std::string> esquemaBase; std::vector<std::map<std::string,std::string>> filasVistaBase;
    if(esVista(tablaBase)){if(profundidad>12)throw std::runtime_error("Demasiada recursion de vistas");auto rv=consultarInterno(consultaVista(tablaBase),profundidad+1);esquemaBase=rv.columnas;for(const auto&fila:rv.filas){std::map<std::string,std::string> m;for(size_t i=0;i<rv.columnas.size();++i)m[rv.columnas[i]]=fila[i];filasVistaBase.push_back(std::move(m));}}
    else esquemaBase=obtenerEsquema(tablaBase);
    if(esquemaBase.empty()) throw std::runtime_error("Tabla o vista no encontrada: "+tablaBase);

    struct JoinInfo{std::string tabla,alias,izq,der,tipo;}; std::vector<JoinInfo> joins;
    while(kw("JOIN")||kw("UNIR")||kw("LEFT")||kw("IZQUIERDA")||kw("RIGHT")||kw("DERECHA")||kw("FULL")||kw("COMPLETO")||kw("CROSS")||kw("CRUZADO")){
        std::string tipo="INNER";
        if(kw("LEFT")||kw("IZQUIERDA")){tipo="LEFT";++p;if(!(toma("JOIN")||toma("UNIR")))throw std::runtime_error("LEFT necesita JOIN");}
        else if(kw("RIGHT")||kw("DERECHA")){tipo="RIGHT";++p;if(!(toma("JOIN")||toma("UNIR")))throw std::runtime_error("RIGHT necesita JOIN");}
        else if(kw("FULL")||kw("COMPLETO")){tipo="FULL";++p;if(!(toma("JOIN")||toma("UNIR")))throw std::runtime_error("FULL necesita JOIN");}
        else if(kw("CROSS")||kw("CRUZADO")){tipo="CROSS";++p;if(!(toma("JOIN")||toma("UNIR")))throw std::runtime_error("CROSS necesita JOIN");}
        else ++p;
        if(p>=t.size())throw std::runtime_error("Falta tabla tras JOIN");std::string tj=t[p++].texto,aj=tj;
        if(p<t.size()&&!esClausula(p)&&!kw("EN")&&!kw("ON")){if(kw("COMO")){++p;if(p>=t.size())throw std::runtime_error("Falta alias JOIN");aj=t[p++].texto;}else aj=t[p++].texto;}
        if(obtenerEsquema(tj).empty())throw std::runtime_error("Tabla JOIN no encontrada: "+tj);
        std::string izq,der;if(tipo!="CROSS"){if(!(toma("EN")||toma("ON")))throw std::runtime_error("JOIN necesita EN");if(p>=t.size())throw std::runtime_error("Falta columna izquierda");izq=t[p++].texto;if(p>=t.size()||t[p++].texto!="=")throw std::runtime_error("JOIN solo admite igualdad");if(p>=t.size())throw std::runtime_error("Falta columna derecha");der=t[p++].texto;}
        joins.push_back({tj,aj,izq,der,tipo});
    }

    auto cualificar=[&](const std::string& alias,const std::map<std::string,std::string>& fila){
        std::map<std::string,std::string> r;for(const auto&[k,v]:fila){r[alias+"."+k]=v;if(!r.count(k))r[k]=v;}return r;
    };
    std::vector<std::map<std::string,std::string>> filas;
    if(esVista(tablaBase)){for(const auto&f:filasVistaBase)filas.push_back(cualificar(aliasBase,f));}else for(const auto&f:listarTodo(tablaBase))filas.push_back(cualificar(aliasBase,f));
    std::vector<std::string> esquemaSalida;for(const auto&c:esquemaBase)esquemaSalida.push_back(joins.empty()?c:aliasBase+"."+c);
    for(const auto&j:joins){
        auto ej=obtenerEsquema(j.tabla);for(const auto&c:ej)esquemaSalida.push_back(j.alias+"."+c);
        std::vector<std::map<std::string,std::string>> nuevas;auto derechas=listarTodo(j.tabla);std::vector<bool> usados(derechas.size(),false);
        for(const auto&acum:filas){bool encontrado=false;
            for(size_t ri=0;ri<derechas.size();++ri){auto q=cualificar(j.alias,derechas[ri]);auto comb=acum;for(const auto&[k,v]:q)if(k.find('.')!=std::string::npos||!comb.count(k))comb[k]=v;
                bool coincide=j.tipo=="CROSS";if(!coincide){auto vi=comb.find(j.izq),vd=comb.find(j.der);if(vi==comb.end()||vd==comb.end())throw std::runtime_error("Columna JOIN no encontrada");coincide=vi->second==vd->second;}
                if(coincide){nuevas.push_back(std::move(comb));encontrado=true;usados[ri]=true;}
            }
            if((j.tipo=="LEFT"||j.tipo=="FULL")&&!encontrado){auto comb=acum;for(const auto&c:ej){comb[j.alias+"."+c]="__JOCARSA_NULL__";if(!comb.count(c))comb[c]="__JOCARSA_NULL__";}nuevas.push_back(std::move(comb));}
        }
        if(j.tipo=="RIGHT"||j.tipo=="FULL")for(size_t ri=0;ri<derechas.size();++ri)if(!usados[ri]){std::map<std::string,std::string> comb;for(const auto&c:esquemaBase){comb[aliasBase+"."+c]="__JOCARSA_NULL__";comb[c]="__JOCARSA_NULL__";}auto q=cualificar(j.alias,derechas[ri]);for(const auto&[k,v]:q)if(k.find('.')!=std::string::npos||!comb.count(k))comb[k]=v;nuevas.push_back(std::move(comb));}
        filas=std::move(nuevas);
    }
    if(estrella){for(const auto&c:esquemaSalida)campos.push_back({c,c,""});}
    auto existeCampo=[&](const std::string& c){
        if(c=="*")return true;
        if(!filas.empty())return filas.front().count(c)>0;
        if(c.find('.')!=std::string::npos)return std::find(esquemaSalida.begin(),esquemaSalida.end(),c)!=esquemaSalida.end();
        return std::find(esquemaBase.begin(),esquemaBase.end(),c)!=esquemaBase.end();
    };
    for(const auto&c:campos)if(!existeCampo(c.nombre))throw std::runtime_error("Columna no encontrada: "+c.nombre);

    std::vector<TokenDQL> donde,having; std::vector<std::string> grupos; std::string orden; bool desc=false; long long limite=-1;
    if(toma("DONDE")){int nivel=0;while(p<t.size()){if(t[p].texto=="(")++nivel;if(t[p].texto==")")--nivel;if(nivel==0&&(kw("AGRUPAR")||kw("TENIENDO")||kw("ORDENAR")||kw("LIMITE")))break;donde.push_back(t[p++]);}}
    if(toma("AGRUPAR")){if(!toma("POR"))throw std::runtime_error("AGRUPAR necesita POR");while(p<t.size()&&!kw("TENIENDO")&&!kw("ORDENAR")&&!kw("LIMITE")){grupos.push_back(t[p++].texto);if(p<t.size()&&t[p].texto==",")++p;else break;}}
    if(toma("TENIENDO")){int nivel=0;while(p<t.size()){if(t[p].texto=="(")++nivel;if(t[p].texto==")")--nivel;if(nivel==0&&(kw("ORDENAR")||kw("LIMITE")))break;having.push_back(t[p++]);}}
    if(toma("ORDENAR")){if(!toma("POR")||p>=t.size())throw std::runtime_error("ORDENAR necesita POR columna");orden=t[p++].texto;if(toma("DESCENDENTE"))desc=true;else toma("ASCENDENTE");}
    if(toma("LIMITE")){if(p>=t.size())throw std::runtime_error("Falta numero tras LIMITE");limite=std::stoll(t[p++].texto);if(limite<0)throw std::runtime_error("LIMITE no puede ser negativo");}
    if(p!=t.size())throw std::runtime_error("Clausula no reconocida: "+t[p].texto);
    for(const auto&g:grupos)if(!existeCampo(g))throw std::runtime_error("Columna AGRUPAR no encontrada: "+g);

    std::vector<std::map<std::string,std::string>> filtradas;
    for(const auto&f:filas)if(donde.empty()||ExprDQL(donde,f).evaluar())filtradas.push_back(f);
    bool hayAgregados=std::any_of(campos.begin(),campos.end(),[](const CampoDQL&c){return c.agregado();});
    if(!hayAgregados&&!grupos.empty()) throw std::runtime_error("AGRUPAR POR requiere al menos una funcion agregada");
    if(!hayAgregados&&!having.empty()) throw std::runtime_error("TENIENDO requiere una consulta agregada");
    if(hayAgregados){for(const auto&c:campos)if(!c.agregado()&&std::find(grupos.begin(),grupos.end(),c.nombre)==grupos.end())throw std::runtime_error("Columna no agregada debe aparecer en AGRUPAR POR: "+c.nombre);}

    ResultadoConsulta r; for(const auto&c:campos)r.columnas.push_back(c.alias);
    std::vector<std::map<std::string,std::string>> salidaMap;
    if(hayAgregados){
        std::map<std::string,std::vector<std::map<std::string,std::string>>> bolsas;
        if(grupos.empty()) bolsas[""]=filtradas;
        else for(const auto&f:filtradas){std::string k;for(const auto&g:grupos)k+=std::to_string(f.at(g).size())+":"+f.at(g)+"|";bolsas[k].push_back(f);}
        if(filtradas.empty()&&grupos.empty()) bolsas[""]={};
        for(const auto&[clave,bolsa]:bolsas){(void)clave;std::map<std::string,std::string> out;
            for(const auto&c:campos){std::string v;
                if(!c.agregado()) v=bolsa.empty()?"":bolsa.front().at(c.nombre);
                else if(c.funcion=="CONTAR"){
                    if(c.nombre=="*")v=std::to_string(bolsa.size());else{long long n=0;for(const auto&f:bolsa)if(f.count(c.nombre)&&!f.at(c.nombre).empty())++n;v=std::to_string(n);}
                } else if(c.funcion=="SUMA"||c.funcion=="MEDIA"){
                    double suma=0;long long n=0;for(const auto&f:bolsa){double x;if(!dqlNumero(f.at(c.nombre),x))throw std::runtime_error(c.funcion+" requiere valores numericos en "+c.nombre);suma+=x;++n;}v=dqlNumeroTexto(c.funcion=="MEDIA"?(n?suma/n:0):suma);
                } else if(c.funcion=="MINIMO"||c.funcion=="MAXIMO"){
                    if(bolsa.empty())v="";else{v=bolsa.front().at(c.nombre);for(const auto&f:bolsa){int cmp=dqlComparar(f.at(c.nombre),v);if((c.funcion=="MINIMO"&&cmp<0)||(c.funcion=="MAXIMO"&&cmp>0))v=f.at(c.nombre);}}
                }
                out[c.alias]=v;out[c.funcion+"("+c.nombre+")"]=v;if(!c.agregado())out[c.nombre]=v;
            }
            if(having.empty()||ExprDQL(having,out).evaluar())salidaMap.push_back(std::move(out));
        }
    } else {
        for(const auto&f:filtradas){std::map<std::string,std::string> out=f;for(const auto&c:campos)out[c.alias]=f.at(c.nombre);salidaMap.push_back(std::move(out));}
    }
    if(!orden.empty()){
        auto tieneOrden=[&](const auto&f){return f.count(orden)>0;}; if(!salidaMap.empty()&&!tieneOrden(salidaMap.front()))throw std::runtime_error("Columna de ordenacion no encontrada: "+orden);
        std::stable_sort(salidaMap.begin(),salidaMap.end(),[&](const auto&a,const auto&b){int c=dqlComparar(a.at(orden),b.at(orden));return desc?c>0:c<0;});
    }
    std::set<std::string> vistos;
    for(const auto&f:salidaMap){std::vector<std::string> fila;std::string clave;for(const auto&c:campos){auto v=f.at(c.alias);fila.push_back(v);clave+=std::to_string(v.size())+":"+v+"|";}if(distinto&&!vistos.insert(clave).second)continue;r.filas.push_back(std::move(fila));if(limite>=0&&(long long)r.filas.size()>=limite)break;}
    return r;
}



ResultadoConsulta JocarsaBBDD::consultar(const std::string& consulta) const{
    std::string q=consulta;
    // Subconsultas no correlacionadas. Se resuelven de dentro hacia fuera.
    for(int guard=0;guard<16;++guard){
        size_t ini=std::string::npos,fin=std::string::npos;int nivel=0,nivelObjetivo=-1;bool comilla=false;char qc=0;
        for(size_t i=0;i<q.size();++i){char c=q[i];if((c=='\''||c=='"')){if(!comilla){comilla=true;qc=c;}else if(qc==c)comilla=false;continue;}if(comilla)continue;
            if(c=='('){++nivel;size_t j=i+1;while(j<q.size()&&std::isspace((unsigned char)q[j]))++j;std::string pref=q.substr(j,std::min<size_t>(11,q.size()-j));std::transform(pref.begin(),pref.end(),pref.begin(),[](unsigned char x){return std::toupper(x);});if(pref.rfind("SELECCIONAR",0)==0){ini=i;nivelObjetivo=nivel;}}
            else if(c==')'&&nivel>0){if(ini!=std::string::npos&&nivel==nivelObjetivo){fin=i;break;}--nivel;}
        }
        if(ini==std::string::npos||fin==std::string::npos)break;
        auto sub=q.substr(ini+1,fin-ini-1);auto rr=consultarInterno(sub,1);if(rr.columnas.size()!=1)throw std::runtime_error("La subconsulta debe devolver una sola columna");
        std::string rep;
        // Si aparece tras EN, producir lista; en otro caso exigir un unico valor escalar.
        size_t k=ini;while(k>0&&std::isspace((unsigned char)q[k-1]))--k;size_t b=k;while(b>0&&std::isalpha((unsigned char)q[b-1]))--b;std::string antes=q.substr(b,k-b);std::transform(antes.begin(),antes.end(),antes.begin(),[](unsigned char x){return std::toupper(x);});
        if(antes=="EN"){rep="(";for(size_t i=0;i<rr.filas.size();++i){if(i)rep+=",";std::string v=rr.filas[i][0];std::string esc;for(char c:v){if(c=='\'')esc+="''";else esc+=c;}rep+="'"+esc+"'";}rep+=")";}
        else {if(rr.filas.size()!=1)throw std::runtime_error("Subconsulta escalar debe devolver exactamente una fila");std::string v=rr.filas[0][0];std::string esc;for(char c:v){if(c=='\'')esc+="''";else esc+=c;}rep="'"+esc+"'";}
        q.replace(ini,fin-ini+1,rep);
    }
    return consultarInterno(q,0);
}

namespace {
using Parents=std::map<std::string,std::string>;
Parents leerPadres(const JocarsaBBDD& db){
 Parents p;auto path=std::filesystem::path(db.instalacion)/db.basededatos/".colecciones_padres.json";
 if(!std::filesystem::exists(path))return p;
 json_object* root=json_object_from_file(path.string().c_str());if(!root)throw std::runtime_error("Jerarquia invalida");
 json_object_object_foreach(root,k,v){if(json_object_is_type(v,json_type_string))p[k]=json_object_get_string(v);}
 json_object_put(root);return p;
}
void guardarPadres(const JocarsaBBDD& db,const Parents& p){
 auto path=std::filesystem::path(db.instalacion)/db.basededatos/".colecciones_padres.json";auto tmp=path;tmp+=".tmp";
 json_object* root=json_object_new_object();for(auto&[k,v]:p)json_object_object_add(root,k.c_str(),json_object_new_string(v.c_str()));
 {std::ofstream f(tmp,std::ios::binary|std::ios::trunc);if(!f){json_object_put(root);throw std::runtime_error("No se puede guardar jerarquia");}f<<json_object_to_json_string_ext(root,JSON_C_TO_STRING_PRETTY);f.flush();if(!f){json_object_put(root);throw std::runtime_error("Error de escritura");}}
 json_object_put(root);std::filesystem::rename(tmp,path);
}
}
bool JocarsaBBDD::crearSubcoleccion(const std::string& parent,const std::string& name){
 std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty()||!nombreValido(name))return false;
 auto a=leerColecciones(*this);if(!a.count(parent)||a.count(name))return false;
 auto p=leerPadres(*this);a[name]={};p[name]=parent;guardarColecciones(*this,a);guardarPadres(*this,p);return true;
}
bool JocarsaBBDD::moverColeccion(const std::string& name,const std::string& parent){
 std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return false;
 auto a=leerColecciones(*this);if(!a.count(name)||(!parent.empty()&&!a.count(parent))||name==parent)return false;
 auto p=leerPadres(*this);std::string x=parent;std::set<std::string> seen;
 while(!x.empty()){if(x==name||!seen.insert(x).second)return false;auto it=p.find(x);if(it==p.end())break;x=it->second;}
 if(parent.empty())p.erase(name);else p[name]=parent;guardarPadres(*this,p);return true;
}
std::vector<std::string> JocarsaBBDD::subcoleccionesDe(const std::string& name) const {
 std::lock_guard<std::mutex> l(mutexColecciones);std::vector<std::string> r;if(basededatos.empty())return r;
 for(auto&[child,parent]:leerPadres(*this))if(parent==name)r.push_back(child);return r;
}
std::vector<std::string> JocarsaBBDD::tablasDeColeccionRecursiva(const std::string& name) const {
 std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return {};
 auto a=leerColecciones(*this);if(!a.count(name))return {};auto p=leerPadres(*this);
 std::set<std::string> tables,visited;std::vector<std::string> pending{name};
 while(!pending.empty()){auto n=pending.back();pending.pop_back();if(!visited.insert(n).second)continue;
  for(auto&t:a[n])tables.insert(t);for(auto&[child,parent]:p)if(parent==n)pending.push_back(child);
 }
 return {tables.begin(),tables.end()};
}
std::string JocarsaBBDD::arbolColecciones() const {
 std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return "{}";
 auto a=leerColecciones(*this);auto p=leerPadres(*this);json_object* root=json_object_new_object();
 for(auto&[n,tables]:a){auto* node=json_object_new_object();auto it=p.find(n);
  if(it==p.end())json_object_object_add(node,"parent",json_object_new_null());
  else json_object_object_add(node,"parent",json_object_new_string(it->second.c_str()));
  auto* arr=json_object_new_array();for(auto&t:tables)json_object_array_add(arr,json_object_new_string(t.c_str()));
  json_object_object_add(node,"tables",arr);json_object_object_add(root,n.c_str(),node);
 }
 std::string out=json_object_to_json_string_ext(root,JSON_C_TO_STRING_PRETTY);json_object_put(root);return out;
}
bool JocarsaBBDD::crearColeccion(const std::string& n){std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty()||!nombreValido(n))return false;auto a=leerColecciones(*this);if(a.count(n))return false;a[n]={};guardarColecciones(*this,a);return true;}
bool JocarsaBBDD::eliminarColeccion(const std::string& n){std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return false;auto a=leerColecciones(*this);if(!a.count(n))return false;auto p=leerPadres(*this);for(auto&[child,parent]:p)if(parent==n)return false;p.erase(n);a.erase(n);guardarColecciones(*this,a);guardarPadres(*this,p);return true;}
std::vector<std::string> JocarsaBBDD::listarColecciones() const {std::lock_guard<std::mutex> l(mutexColecciones);std::vector<std::string> r;if(basededatos.empty())return r;for(auto& [n,v]:leerColecciones(*this))r.push_back(n);return r;}
bool JocarsaBBDD::agregarTablaColeccion(const std::string& t,const std::string& n){std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return false;auto tablas=listarTablas();if(std::find(tablas.begin(),tablas.end(),t)==tablas.end())return false;auto a=leerColecciones(*this);auto it=a.find(n);if(it==a.end()||!it->second.insert(t).second)return false;guardarColecciones(*this,a);return true;}
bool JocarsaBBDD::quitarTablaColeccion(const std::string& t,const std::string& n){std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return false;auto a=leerColecciones(*this);auto it=a.find(n);if(it==a.end()||!it->second.erase(t))return false;guardarColecciones(*this,a);return true;}
std::vector<std::string> JocarsaBBDD::tablasDeColeccion(const std::string& n) const {std::lock_guard<std::mutex> l(mutexColecciones);if(basededatos.empty())return {};auto a=leerColecciones(*this);auto it=a.find(n);if(it==a.end())return {};return {it->second.begin(),it->second.end()};}
std::vector<std::string> JocarsaBBDD::coleccionesDeTabla(const std::string& t) const {std::lock_guard<std::mutex> l(mutexColecciones);std::vector<std::string> r;if(basededatos.empty())return r;for(auto& [n,v]:leerColecciones(*this))if(v.count(t))r.push_back(n);return r;}
