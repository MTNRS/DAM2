#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Descarga notificaciones recibidas desde 2026-10-30 hasta ahora (Madrid)."""
import os
import re
import email
import imaplib
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime, timedelta, date
from zoneinfo import ZoneInfo
from getpass import getpass
from email import policy
from email.header import decode_header

USUARIO = os.getenv('GMAIL_USER', 'jocarsa2@gmail.com')
CLAVE = os.getenv('GMAIL_APP_PASSWORD', '')
ASUNTO = 'Actualización de calificación · '
ZONA = ZoneInfo('Europe/Madrid')
INICIO = date(2026, 10, 30)
DESTINO = Path('correo_eml') / 'actualizaciones_calificacion_desde_2026-10-30'
DB = Path('actualizaciones_calificacion_descargadas.sqlite')


def decodificar(valor):
    partes = []
    for contenido, codificacion in decode_header(valor or ''):
        if isinstance(contenido, bytes):
            try:
                partes.append(contenido.decode(codificacion or 'utf-8', errors='replace'))
            except LookupError:
                partes.append(contenido.decode('utf-8', errors='replace'))
        else:
            partes.append(contenido)
    return ''.join(partes)


def main():
    global CLAVE
    if not CLAVE:
        CLAVE = getpass('Contraseña de aplicación Gmail: ')
    ahora = datetime.now(ZONA)
    DESTINO.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB)
    db.execute('CREATE TABLE IF NOT EXISTS descargados (message_hash TEXT PRIMARY KEY, ruta TEXT NOT NULL, fecha_descarga TEXT DEFAULT CURRENT_TIMESTAMP)')
    db.commit()
    mail = imaplib.IMAP4_SSL('imap.gmail.com', timeout=120)
    descargados = 0
    duplicados = 0
    revisados = 0
    try:
        mail.login(USUARIO, CLAVE)
        estado, _ = mail.select('INBOX', readonly=True)
        if estado != 'OK':
            raise RuntimeError('No se pudo seleccionar INBOX')
        # Gmail almacena la fecha interna en UTC; ampliar un día a cada lado
        # permite verificar sin omisiones los límites de Europe/Madrid.
        inicio = (INICIO - timedelta(days=1)).strftime('%d-%b-%Y')
        fin = (ahora.date() + timedelta(days=2)).strftime('%d-%b-%Y')
        estado, datos = mail.uid('SEARCH', None, 'SINCE', inicio, 'BEFORE', fin)
        if estado != 'OK':
            raise RuntimeError('Error al buscar mensajes por fecha')
        uids = datos[0].split() if datos and datos[0] else []
        print(f'Intervalo local: {INICIO} 00:00 hasta {ahora.isoformat()} | Candidatos: {len(uids)}')
        for uid in uids:
            # BODY.PEEK evita marcar el mensaje como leído.
            estado, partes = mail.uid('FETCH', uid, '(BODY.PEEK[])')
            if estado != 'OK':
                print(f'No se pudo recuperar UID {uid.decode()}')
                continue
            bruto = next((p[1] for p in partes if isinstance(p, tuple) and isinstance(p[1], bytes)), None)
            if not bruto:
                continue
            revisados += 1
            mensaje = email.message_from_bytes(bruto, policy=policy.default)
            asunto = decodificar(mensaje.get('Subject', ''))
            if ASUNTO not in asunto:
                continue
            # INTERNALDATE es la fecha de recepción IMAP, más fiable que Date.
            estado_fecha, resp_fecha = mail.uid('FETCH', uid, '(INTERNALDATE)')
            if estado_fecha != 'OK':
                continue
            linea = next((p for p in resp_fecha if isinstance(p, bytes) and b'INTERNALDATE' in p), b'')
            coincidencia = re.search(rb'INTERNALDATE "([^"]+)"', linea)
            if not coincidencia:
                print(f'UID {uid.decode()}: sin INTERNALDATE verificable; omitido')
                continue
            # INTERNALDATE incluye desplazamiento; interpretarlo directamente.
            from email.utils import parsedate_to_datetime
            recibido = parsedate_to_datetime(coincidencia.group(1).decode('ascii'))
            if not (datetime.combine(INICIO, datetime.min.time(), ZONA) <= recibido.astimezone(ZONA) <= ahora):
                continue
            huella = hashlib.sha256(bruto).hexdigest()
            fila = db.execute('SELECT ruta FROM descargados WHERE message_hash=?', (huella,)).fetchone()
            if fila and Path(fila[0]).exists():
                duplicados += 1
                continue
            nombre = f'{recibido.astimezone(ZONA):%Y%m%d_%H%M%S}_{huella[:16]}.eml'
            ruta = DESTINO / nombre
            ruta.write_bytes(bruto)
            db.execute('INSERT OR REPLACE INTO descargados (message_hash, ruta) VALUES (?, ?)', (huella, str(ruta)))
            db.commit()
            descargados += 1
            print(f'[{descargados}] {asunto} -> {ruta}')
    finally:
        try:
            mail.logout()
        except Exception:
            pass
        db.close()
    print(f'Finalizado. Revisados: {revisados} | Descargados: {descargados} | Duplicados: {duplicados}')
    print(f'Destino: {DESTINO.resolve()}')


if __name__ == '__main__':
    main()
