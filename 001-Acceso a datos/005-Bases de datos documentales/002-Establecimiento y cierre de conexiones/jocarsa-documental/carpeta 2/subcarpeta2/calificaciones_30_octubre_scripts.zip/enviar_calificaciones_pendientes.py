#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reenvía notificaciones de calificaciones archivadas como EML.

Ejemplos:
  python3 reenviar_calificaciones_eml.py --mode test --limit 5
  python3 reenviar_calificaciones_eml.py --mode production --confirm-production
  python3 reenviar_calificaciones_eml.py --mode production --confirm-production --dry-run

El modo test solo entrega al buzón de pruebas. El modo production exige
confirmación explícita. Se registra la aceptación SMTP, no la entrega final.
"""
import argparse
import os
import hashlib
import json
import logging
import re
import smtplib
import sqlite3
import ssl
import time
import sys
from datetime import datetime, timezone
from email import policy
from email.message import EmailMessage
from email.parser import BytesParser
from email.utils import formataddr, getaddresses, make_msgid, parseaddr
from pathlib import Path
from html.parser import HTMLParser

SMTP_HOST = 'sis-imf-capitol-com.correoseguro.dinaserver.com'
SMTP_PORT = 465
SMTP_USER = 'noreply@sis.imf-capitol.com'
SMTP_PASS = os.getenv('CAPITOL_SMTP_PASSWORD', '')
FROM_EMAIL = 'noreply@sis.imf-capitol.com'
FROM_NAME = 'SIS · Capitol'
TEST_RECIPIENT = 'jocarsa2@gmail.com'
SECRETARIA_EMAIL = 'secretaria@capitolformacion.com'
SUBJECT_PREFIX = 'Actualización de calificación · '

# Eliminar exclusivamente los bloques hoja del aviso de prueba y del diagnóstico Moodle.
# No capturar contenedores exteriores: hacerlo destruiría la plantilla HTML.
TEST_DIV_RE = re.compile(
    r'<div\b[^>]*>(?:(?!<div\b|</div\s*>).)*?ENV[IÍ]O\s+DE\s+PRUEBA'
    r'(?:(?!<div\b|</div\s*>).)*?</div\s*>', re.I | re.S)
MOODLE_P_RE = re.compile(
    r'<p\b[^>]*>(?:(?!<p\b|</p\s*>).)*?Moodle\s*:'
    r'(?:(?!<p\b|</p\s*>).)*?</p\s*>', re.I | re.S)

def clean_html(html):
    cleaned = TEST_DIV_RE.sub('', html)
    cleaned = MOODLE_P_RE.sub('', cleaned)
    visible = re.sub(r'<[^>]*>', ' ', cleaned)
    if re.search(r'ENV[IÍ]O\s+DE\s+PRUEBA|Moodle\s*:', visible, re.I):
        raise ValueError('No se pudo limpiar completamente el HTML de prueba/Moodle')
    # Garantía de que el cuerpo principal sigue intacto.
    if 'Actualización de calificación' not in visible or 'Calificación' not in visible:
        raise ValueError('La limpieza ha eliminado contenido académico: envío cancelado')
    return cleaned

def clean_plain(text):
    lines = []
    for line in text.splitlines():
        if re.search(r'ENV[IÍ]O\s+DE\s+PRUEBA|^\s*Moodle\s*:', line, re.I):
            continue
        lines.append(line)
    return '\n'.join(lines).strip() + '\n'

def extract_bodies(msg):
    plain, html = None, None
    for part in msg.walk():
        if part.get_content_disposition() == 'attachment':
            continue
        typ = part.get_content_type()
        if typ not in ('text/plain', 'text/html'):
            continue
        try:
            content = part.get_content()
        except Exception:
            payload = part.get_payload(decode=True) or b''
            content = payload.decode(part.get_content_charset() or 'utf-8', errors='replace')
        if typ == 'text/plain' and plain is None:
            plain = content
        if typ == 'text/html' and html is None:
            html = content
    return plain, html

# Restrict recipient extraction to named academic email fields, not arbitrary
# email addresses in headers, test banners or Moodle metadata.
FIELD_RE = re.compile(r'^\s*(Email\s+alumno|Email\s+tutor|Email\s+profesor(?:es)?)\s*:\s*(.*?)\s*$', re.I)
EMAIL_RE = re.compile(r'(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?![\w.-])', re.I)

class TableFields(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_td = False
        self.current = []
        self.cells = []
        self.rows = []
    def handle_starttag(self, tag, attrs):
        if tag == 'td':
            self.in_td = True
            self.current = []
        if tag == 'tr':
            self.cells = []
    def handle_data(self, data):
        if self.in_td:
            self.current.append(data)
    def handle_endtag(self, tag):
        if tag == 'td' and self.in_td:
            self.cells.append(''.join(self.current).strip())
            self.in_td = False
        elif tag == 'tr' and self.cells:
            self.rows.append(self.cells[:])

def academic_recipients(plain, html):
    values = []
    if plain:
        for line in plain.splitlines():
            match = FIELD_RE.match(line)
            if match:
                values.extend(EMAIL_RE.findall(match.group(2)))
    if html:
        parser = TableFields()
        parser.feed(html)
        for cells in parser.rows:
            if len(cells) >= 2 and re.fullmatch(r'Email\s+(?:alumno|tutor|profesor(?:es)?)', cells[0], re.I):
                values.extend(EMAIL_RE.findall(' '.join(cells[1:])))
    result = {}
    for value in values:
        addr = value.strip().lower()
        if '\n' not in addr and '\r' not in addr:
            result[addr] = addr
    return sorted(result.values())

def prepare(path, mode):
    raw = path.read_bytes()
    original = BytesParser(policy=policy.default).parsebytes(raw)
    subject = str(original.get('Subject', ''))
    if SUBJECT_PREFIX.casefold() not in subject.casefold():
        raise ValueError('Asunto no coincide con el filtro de calificaciones')
    plain, html = extract_bodies(original)
    if not plain and not html:
        raise ValueError('Mensaje sin cuerpo legible')
    academic = academic_recipients(plain, html)
    recipients = [TEST_RECIPIENT] if mode == 'test' else sorted(set(academic + [SECRETARIA_EMAIL]))
    if mode == 'production' and not academic:
        raise ValueError('No se han encontrado destinatarios académicos: envío cancelado')
    plain = clean_plain(plain) if plain else None
    html = clean_html(html) if html else None
    if html:
        html = re.sub(r'SIS\s*[·-]\s*IMF\s+Capitol', 'SIS · Capitol', html, flags=re.I)
    if plain:
        plain = re.sub(r'SIS\s*[·-]\s*IMF\s+Capitol', 'SIS · Capitol', plain, flags=re.I)
    outgoing = EmailMessage(policy=policy.SMTP)
    outgoing['From'] = formataddr((FROM_NAME, FROM_EMAIL))
    outgoing['To'] = ', '.join(recipients)
    outgoing['Subject'] = subject
    outgoing['Date'] = datetime.now(timezone.utc).strftime('%a, %d %b %Y %H:%M:%S %z')
    outgoing['Message-ID'] = make_msgid(domain='sis.imf-capitol.com')
    outgoing['X-Source-Message-ID'] = str(original.get('Message-ID', ''))
    if plain:
        outgoing.set_content(plain, charset='utf-8')
        if html:
            outgoing.add_alternative(html, subtype='html', charset='utf-8')
    else:
        outgoing.set_content('Notificación de actualización de calificación. Consulte la versión HTML.', charset='utf-8')
        outgoing.add_alternative(html, subtype='html', charset='utf-8')
    return outgoing, recipients, academic, hashlib.sha256(raw).hexdigest()

def init_db(path):
    conn = sqlite3.connect(path)
    conn.execute('''CREATE TABLE IF NOT EXISTS attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        mode TEXT NOT NULL, source_sha256 TEXT, source_file TEXT,
        recipients TEXT, status TEXT NOT NULL, detail TEXT,
        outbound_message_id TEXT)''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_attempts ON attempts(mode, source_sha256, status)')
    conn.commit()
    return conn

def log_attempt(conn, mode, digest, path, recipients, status, detail='', message_id=''):
    conn.execute('INSERT INTO attempts(mode,source_sha256,source_file,recipients,status,detail,outbound_message_id) VALUES (?,?,?,?,?,?,?)',
                 (mode, digest, str(path), json.dumps(recipients, ensure_ascii=False), status, detail, message_id))
    conn.commit()
    logging.info('%s | %s | %s | %s', status, path.name, ', '.join(recipients), detail)

def already_sent(conn, mode, digest):
    return conn.execute("SELECT 1 FROM attempts WHERE mode=? AND source_sha256=? AND status='accepted_by_smtp' LIMIT 1", (mode, digest)).fetchone() is not None

def format_duration(seconds):
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours:02d}:{minutes:02d}:{seconds:02d}'


def show_progress(done, total, started, delay, last_smtp_start=None, label=''):
    elapsed = time.monotonic() - started
    remaining = max(0, total - done)
    # Estimate from observed processing speed; include the minimum SMTP interval.
    if done:
        avg = elapsed / done
        eta = remaining * max(avg, delay)
    else:
        eta = max(0, remaining - 1) * delay
    if last_smtp_start is not None and remaining:
        eta += max(0, delay - (time.monotonic() - last_smtp_start))
    width = 28
    filled = round(width * done / total) if total else width
    bar = '█' * filled + '░' * (width - filled)
    suffix = f' | {label}' if label else ''
    sys.stdout.write(f'\r[{bar}] {done}/{total} ({(done / total * 100) if total else 100:.1f}%)'
                     f' | Transcurrido {format_duration(elapsed)} | ETA {format_duration(eta)}{suffix}   ')
    sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--source', default='correo_eml/actualizaciones_calificacion_desde_2026-10-30', help='Directorio de archivos .eml')
    parser.add_argument('--mode', choices=('test', 'production'), default='test')
    parser.add_argument('--confirm-production', action='store_true')
    parser.add_argument('--dry-run', action='store_true', help='No conectar ni enviar por SMTP')
    parser.add_argument('--resend', action='store_true', help='Reenviar incluso si se aceptó previamente por SMTP')
    parser.add_argument('--delay', type=float, default=20.0, help='Segundos mínimos entre intentos SMTP (por defecto: 20)')
    parser.add_argument('--limit', type=int, default=None, help='En modo test, enviar como máximo los primeros X correos pendientes')
    parser.add_argument('--db', default='reenvio_calificaciones.sqlite')
    parser.add_argument('--log', default='reenvio_calificaciones.log')
    args = parser.parse_args()
    if args.limit is not None and (args.limit < 1 or args.mode != 'test'):
        parser.error('--limit requiere --mode test y un entero positivo')
    if args.delay < 0:
        parser.error('--delay no puede ser negativo')
    if not args.dry_run and not SMTP_PASS:
        parser.error('Configura CAPITOL_SMTP_PASSWORD antes de enviar')
    if args.mode == 'production' and not args.confirm_production:
        parser.error('Production requiere --confirm-production')
    logging.basicConfig(filename=args.log, level=logging.INFO, encoding='utf-8', format='%(asctime)s %(levelname)s %(message)s')
    source = Path(args.source)
    files = sorted(source.rglob('*.eml')) if source.is_dir() else ([source] if source.is_file() else [])
    if not files:
        parser.error(f'No se encontraron archivos EML en {source}')
    conn = init_db(args.db)
    stats = {'sent': 0, 'skipped': 0, 'errors': 0, 'dry_run': 0}
    last_smtp_start = None
    started = time.monotonic()
    try:
        print('Calculando correos pendientes y comprobando el historial SQLite...')
        pending = []
        for path in files:
            try:
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                if already_sent(conn, args.mode, digest) and not args.resend:
                    stats['skipped'] += 1
                    continue
                pending.append((path, digest))
                if args.limit is not None and len(pending) >= args.limit:
                    break
            except Exception as exc:
                stats['errors'] += 1
                logging.exception('Error leyendo %s: %s', path, exc)
        total = len(pending)
        print(f'Total archivos: {len(files)} | Ya enviados omitidos: {stats["skipped"]} | Pendientes en esta ejecución: {total}')
        show_progress(0, total, started, args.delay)
        for index, (path, digest) in enumerate(pending, start=1):
            try:
                msg, recipients, academic, digest = prepare(path, args.mode)
                if args.dry_run:
                    stats['dry_run'] += 1
                    log_attempt(conn, args.mode, digest, path, recipients, 'dry_run', f'academic={academic}')
                else:
                    if last_smtp_start is not None:
                        wait = max(0.0, args.delay - (time.monotonic() - last_smtp_start))
                        while wait > 0:
                            show_progress(index - 1, total, started, args.delay, last_smtp_start, f'Espera {wait:.0f}s')
                            time.sleep(min(1, wait))
                            wait = max(0.0, args.delay - (time.monotonic() - last_smtp_start))
                    show_progress(index - 1, total, started, args.delay, last_smtp_start, 'Enviando...')
                    last_smtp_start = time.monotonic()
                    with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30, context=ssl.create_default_context()) as smtp:
                        smtp.login(SMTP_USER, SMTP_PASS)
                        smtp.send_message(msg, from_addr=FROM_EMAIL, to_addrs=recipients)
                    stats['sent'] += 1
                    log_attempt(conn, args.mode, digest, path, recipients, 'accepted_by_smtp', '', str(msg['Message-ID']))
            except Exception as exc:
                stats['errors'] += 1
                log_attempt(conn, args.mode, digest, path, [], 'error', f'{type(exc).__name__}: {exc}')
                print(f'\n[ERROR] {path.name}: {exc}')
            show_progress(index, total, started, args.delay, last_smtp_start)
        print()
    finally:
        conn.close()
    print('Resumen:', json.dumps(stats, ensure_ascii=False))
    print('Tiempo transcurrido:', format_duration(time.monotonic() - started))
    print('Log:', args.log, '| SQLite:', args.db)

if __name__ == '__main__':
    main()
