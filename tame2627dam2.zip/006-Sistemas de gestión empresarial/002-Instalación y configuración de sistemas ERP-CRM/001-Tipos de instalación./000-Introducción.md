# Tipos de instalación.

