# El desfase objeto-relacional

