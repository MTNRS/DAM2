# Gestión de transacciones

