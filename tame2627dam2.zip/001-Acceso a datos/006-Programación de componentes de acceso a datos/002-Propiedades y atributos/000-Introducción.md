# Propiedades y atributos

