# Concepto de componente

