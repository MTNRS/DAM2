# Excepciones detección y tratamiento

