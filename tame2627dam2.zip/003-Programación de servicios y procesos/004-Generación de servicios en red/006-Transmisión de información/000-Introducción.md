# Transmisión de información

