# Sockets. Tipos. Características

