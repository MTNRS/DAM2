# Determinación de recursos.

