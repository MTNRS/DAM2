# Recopilación de información

