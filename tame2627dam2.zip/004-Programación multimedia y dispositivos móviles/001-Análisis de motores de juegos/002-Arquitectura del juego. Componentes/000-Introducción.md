# Arquitectura del juego. Componentes

