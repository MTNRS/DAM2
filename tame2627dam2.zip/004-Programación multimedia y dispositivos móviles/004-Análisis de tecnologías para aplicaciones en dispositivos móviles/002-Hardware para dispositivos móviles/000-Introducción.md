# Hardware para dispositivos móviles

