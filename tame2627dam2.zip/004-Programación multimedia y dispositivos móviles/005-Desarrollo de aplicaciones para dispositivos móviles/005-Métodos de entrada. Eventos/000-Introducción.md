# Métodos de entrada. Eventos

