#include <stdio.h>

int main() {
    float altura = 1.78;
    printf("Mi altura es de %d metros \n",edad);
    return 0;
}